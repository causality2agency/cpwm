#
function() {
  # @_1_07_16@ 改用r制作fa文件，为了自制序列名
  # [思路]基因组，区域=>区域的序列
  wd <- .wk[[ 'task_folder']]( '_1_07_11_095820')
  org_v <- .wk[[ 'get_fun']]( '物种._1_06_24_214742')()
  region_list <- list( 'promoter_region' = list( c( 2000, 1000), c( 2000, 500))) # 上游2000，下游1000
  region_fp_part <- function( region_type, region_range) {
    # @_1/10/15@
    paste0( region_range[ 1], '_', switch( region_type, 'promoter_region' = 'tss', .wk[[ 'base_browser']]( '_1_10_15_154016')), '_', region_range[ 2])
  }
  r <- .wk[[ 'get_fun']]( '做项目/参数组合._1_10_15_172453')(
    'org' = org_v,
    'region' = local({ # @_1/10/15@
      r <- .wk[[ 'acc_list']]()
      for( region_type in names( region_list)) {
        for( range_1 in region_list[[ region_type]]) {
          r( 'add', region_fp_part( region_type, range_1))
        }
      }
      unlist( r())
    })
  )
  .wk[[ 'with_wd']]( wd, {
    gene_folder <- .wk[[ 'get_fun']]( '基因/_1_06_22_155510')()
    genome_folder <- .wk[[ 'get_fun']]( '基因组/_1_06_21_171640')()
    for( org1 in org_v) {
      #org1 <- '华占'
      #org1 <- 'osa'
      for( region_type in names( region_list)) {
        { # bed
          region <- sapply( region_list[[ region_type]], function( range_1) region_fp_part( region_type, range_1))
          wj2_bed_v <- paste0( region, '.', org1, '.bed')
          wj2_fa_v <- .wk[[ 'sub']]( wj2_bed_v, 'bed$', 'fa.gz')
          if( ! all( file.exists( wj2_fa_v))) {
            genome_file <- 
              if( org1 == '华占') {
                local({
                  a <- .wk[[ 'get_fun']]( '水稻/基因组._2_02_16_141026')()
                  file.path( a, 'Huazhan.genome.fasta.gz')
                })
              } else
                list.files( genome_folder, paste0( org1, '.fasta.gz$'), full = TRUE)
            genome <- Rsamtools::FaFile( genome_file)
            gff_file <- 
              if( org1 == '华占') {
                local({
                  a <- .wk[[ 'get_fun']]( '水稻/基因组._2_02_16_141026')()
                  file.path( a, 'HZ.gtf.gz')
                })
              } else
                file.path( gene_folder, paste0( 'annotation.all_transcripts.all_features.', org1, '.gff3.gz'))
            gff <- rtracklayer::import( gff_file)
            genes <- gff[ gff$type == head( intersect( c( 'gene', 'transcript'), levels( gff$type)), 1)]
            tss <- GenomicRanges::resize( genes, width = 1, fix = 'start')
            if(0){
              i <- match( c( '+', '-'), as.vector( GenomicRanges::strand( genes)))
              GenomicRanges::start( genes[ i])
              GenomicRanges::start( tss[ i])
            }
            if(0){ # integrative_orthology.gma.tsv.gz 的基因来自所有染色体
              GenomicRanges::mcols( gff)[['type']]
              .wk[['sys_ls']](gene_folder)
              .wk[['sys_bash']](genome_folder)
              .wk[['sys_less']](file.path( gene_folder, 'annotation.all_transcripts.gma.csv.gz'))
              gene_with_orthology <- .wk[['sys']]( c( 'gzip -cd', file.path( gene_folder, 'integrative_orthology.gma.tsv.gz'), '| cut -f1', '| uniq | sort | uniq'), intern = 1)
              intersect( GenomicRanges::mcols( genes)[['gene_id']], gene_with_orthology)
              genes[ ! ( GenomicRanges::mcols( genes)[['gene_id']] %in% gene_with_orthology)]
            }
            for( range_1_i in seq_along( region_list[[ 'promoter_region']])) {
              #wj2 <- wj2_bed_v[ range_1_i]
              wj2 <- wj2_fa_v[ range_1_i]
              if( file.exists( wj2))
                next
              range_1 <- region_list[[ 'promoter_region']][[ range_1_i]]
              promoter_region_1 <- GenomicRanges::promoters(
                tss,
                upstream = range_1[ 1],
                downstream = range_1[ 2] + 1
              )
              { # 左侧出界
                i <- which( GenomicRanges::start( promoter_region_1) < 1)
                if( length( i))
                  GenomicRanges::start( promoter_region_1[ i]) <- 1
              }
              { # 右侧出界
                chr_info <-
                  if( org1 == '华占') {
                    local({
                      a <- dirname( genome_file)
                      a <- file.path( a, 'Huazhan.genome.fasta.gz.fai')
                      .wk[['dt_fread']]( a, cn = 0)
                    })
                  } else
                    .wk[['dt_fread']]( file.path( genome_folder, paste0( org1, '.fasta.gz.fai')), cn = 0)
                for( chr1 in sort( levels( GenomicRanges::seqnames( promoter_region_1)))) {
                  chr1_len <- chr_info[ match( chr1, V1), V2]
                  chr1_row <- which( as.vector( GenomicRanges::seqnames( promoter_region_1) == chr1))
                  i <- which( GenomicRanges::end( promoter_region_1[ chr1_row]) > chr1_len)
                  if( length( i)) {
                    .wk[['hs.msg']]( chr1)
                    GenomicRanges::end( promoter_region_1[ chr1_row[ i]]) <- chr1_len
                  }
                }
              }
              if(0){
                promoter_region_1_bed <- data.frame(
                  chrom = GenomicRanges::seqnames( promoter_region_1),
                  start = GenomicRanges::start( promoter_region_1) - 1,  # 转换为0-based
                  end = GenomicRanges::end( promoter_region_1),
                  name = genes$ID,
                  score = '.',
                  strand = GenomicRanges::strand( promoter_region_1)
                )
                .wk[['dt_fwrite']]( promoter_region_1_bed, wj2)
              }
              ## if( org1 == 'osa')
              ##   .wk[[ 'base_browser']]( '_2_02_22_010948')
              {
                promoter_region_1_seq <- Biostrings::getSeq( genome, promoter_region_1)
                names( promoter_region_1_seq) <- .wk[['with']](
                  promoter_region_1, tss,
                  paste( x1$gene_id, GenomicRanges::seqnames( x1), GenomicRanges::strand( x1), GenomicRanges::start( x1), GenomicRanges::start( x2), GenomicRanges::end( x1), sep = '|')
                )
                Biostrings::writeXStringSet( promoter_region_1_seq, wj2, compress = TRUE)
              }
            }
          }
          for( region_i in seq_along( region))
            r[ org1, region[ region_i]] <<- file.path( wd, wj2_fa_v[ region_i])
        }
        next
        { # fa
          wj2_fa_v <- .wk[['sub']]( wj2_bed_v, 'bed$', 'fa.gz')
          .wk[[ 'sys']]( c( 'ls -alh', wj2_fa_v))
          unlink(wj2_fa_v)
          if( ! all( file.exists( wj2_fa_v))) {
            bedtools_file <- .wk[['get_fun']]( '用conda/找软件._1_07_12_091131')( 'bedtools')
            .wk[['get_fun']]( '软件版本控制._1_07_13_202140')( bin_fp = bedtools_file, uid = '_1_07_14_181524')
            #genome_file <- list.files( genome_folder, paste0( org1, '.fasta.gz$'), full = TRUE)
            for( range_1_i in seq_along( region_list)) {
              wj2 <- wj2_fa_v[ range_1_i]
              wj_bed <- wj2_bed_v[ range_1_i]
              if( file.exists( wj2))
                next
              .wk[['sys']]( c( .wk[['sys_safe_file_path']]( bedtools_file), 'getfasta -fi', .wk[['sys_safe_file_path']]( genome_file), '-bed', shQuote( wj_bed), '-s', '-name', '| gzip >', shQuote( wj2)))
            }
          }
        }
      }
    }
  })
  return( r)
  r <- .wk[[ 'list_file']]( wd, '\\.fa\\.gz$')
  names( r) <- local({ # 加物种名作为名称
    a <- base::basename( r)
    a <- base::strsplit( a, '\\.')
    sapply( a, function( x) tail( x, 3)[ 1])
  })
  r
}
