#
function() {
  wd <- .wk[[ 'task_folder']]( '_2_01_11_212321')
  fimo_fp <- .wk[[ 'get_fun']]( '用conda/找软件._1_07_12_091131')( 'fimo')
  .wk[[ 'get_fun']]( '软件版本控制._1_07_13_202140')( fimo_fp, '_1_07_15_134113')
  .wk[[ 'with_wd']]( wd, {
    setwd( wd)
    pwm_folder <- .wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')()
    pwm_file <- .wk[[ 'list_file']]( pwm_folder)
    target_region_file <- .wk[[ 'get_fun']]( '目标区域/_1_07_11_095820')() # <<_1_08_11_221531>>

    # 用fimo
    target_region_file.folder <- function( x) {
      .wk[[ 'sub']]( basename( x), '\\.fa(\\.gz)?$')
    }
    for( target_region_file1 in target_region_file) { # 生成每个物种的目标区域的每个pwm_file的结果 <<_1_08_08_125927>>
      .wk[[ 'mclapply']]( pwm_file, function( pwm1_file) {
        fp2 <- .wk[[ 'file_path']](
          target_region_file.folder( target_region_file1),
          .wk[[ 're']]( base::basename( pwm1_file), '\\.[^\\.]+$', '.fimo_out.tsv.gz')
        )
        if( base::file.exists( fp2)) return()
        .wk[[ 'sys']]( base::c(
          .wk[[ 'sys_safe_file_path']]( fimo_fp),
          '--text',
          .wk[[ 'sys_safe_file_path']]( pwm1_file),
          .wk[[ 'sys_cat_text']]( target_region_file1, as_file = 1),
          '| cut -f3-',
          '| gzip >', .wk[[ 'sys_safe_file_path']]( fp2))
        )
      }, nc = 10)
      if(0)for( pwm1_file in pwm_file) {
        fp2 <- .wk[['file_path']]( .wk[['sub']]( basename( target_region_file1), '\\.fa(\\.gz)?$'), .wk[['re']]( basename( pwm1_file), '\\.[^\\.]+$', '.fimo_out.tsv.gz'))
        if( file.exists( fp2)) next
        .wk[['with_msg']](
          fp2,
          .wk[['sys']]( c(
            .wk[['sys_safe_file_path']]( fimo_fp),
            '--text',
            .wk[['sys_safe_file_path']]( pwm1_file),
            '<( gzip -cd', .wk[['sys_safe_file_path']]( target_region_file1), ')',
            '| cut -f3-',
            '| gzip >', .wk[['sys_safe_file_path']]( fp2))
          )
        )
      }
    }

    { # cmm
      # 物种
      org_v <- .wk[[ 'get_fun']]( '物种._1_06_24_214742')()
      org_centric <- 'gma'#'ath'
      org_other <- .wk[[ '%rm%']]( org_v, org_centric)

      { # 每个物种的所有基因
        gene_folder <- .wk[[ 'get_fun']]( '基因/_1_06_22_155510')()
        org_gene <- list()
        for( org1 in org_v) {
          a <- file.path( gene_folder, paste0( 'annotation.all_transcripts.all_features.', org1, '.gff3.gz'))
          a <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( .wk[[ 'fill_list']]( 3, 'gene'), fp = a, ci2 = 9)
          .wk[[ 'dt_reset_name']]( a)
          a[, 'V1' := tolower( .wk[[ 're']]( V1, '(?i)(?<=gene_id=)[^;]+'))]
          org_gene[[ org1]] <- a
        }
        sum( sapply( org_gene, \( x) x[, .N]))
      }
      { # @_1/08/22@ 用第2个同源基因信息来源 <<_1_08_22_210611>>
        orth_fp <- file.path( gene_folder, paste0( 'integrative_orthology.', org_centric, '.tsv.gz'))
        .wk[[ 'sys_head']]( orth_fp)
        org_orth <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( list( 'BHIF' = 1, 'ORTHO' = 1, 'ortholog-species' = org_other), orth_fp, head = 1, skip = 1, exclude_ci1 = c( 'BHIF', 'ORTHO'))
        for( cn in c( '#query-gene', 'ortholog-gene')) { # 基因名称改为小写
          data.table::set( org_orth, , cn, tolower( org_orth[[ cn]]))
        }
        {
          all( org_orth[[ '#query-gene']] %in% org_gene[[ org_centric]][, V1])
          for( org1 in org_orth[, unique( `ortholog-species`)]) {
            if( ! all( org_orth[ org1, on = 'ortholog-species', `ortholog-gene`] %in% org_gene[[ org1]][, V1])) {
              stop( '[_1_10_08_130115]')
            }
          }
        }
        { # 每次处理1个pwm @_1_08_02_222524@
          pwm_db <- {
            a <- lapply( target_region_file, function( x) {
              x <- target_region_file.folder( x)
              x <- .wk[[ 'list_file']]( x, F = 0)
              .wk[[ 'sub']]( x, '(?i)\\.fimo_out\\.tsv\\.gz$')
            })
            sort( unique( unlist( a)))
          }
          length( pwm_db) # 1480
          fimo_out_ci_wanted <- c( 1, 6)
          p_value_cutoff <- 1e-4
          score_fp2 <- 'score/integrative-orthology'
          score_fp2 <- 'score/integrative-orthology/nonTarget' # @_1/10/08@
          .wk[[ 'folder_path']]( score_fp2)
          .wk[[ 'sys_ls']]( score_fp2)
          .wk[[ 'sys_head']]( file.path( score_fp2, 'M11491_2.00.2000_tss_500.tsv.gz'))
          pwm_1 <- 'M00216_2.00'
          pwm_1 <- 'M00008_2.00'
          ranmdom50pwm <- .wk[[ 'eval_lazy']]({
            sort( sample( pwm_db, 50))
          }, file = 'ranmdom50pwm.rd')
          .wk[[ 'do_list']]( seq_along( pwm_db), \( pwm_1_i) {
            pwm_1 <- pwm_db[ pwm_1_i]
            for( region_1 in intersect( '2000_tss_500', dimnames( target_region_file)[[ 'region']])) {
              fp2 <- file.path( score_fp2, paste0( pwm_1, '.', region_1, '.by_pbinom.tsv.gz'))
              if( file.exists( fp2)) next
              .wk[[ 'hs.msg']]( fp2)
              pwm_1.fimo_out_fp <- {
                x <- sapply( target_region_file[, region_1], function( x) {
                  target_region_file.folder( x)
                })
                x <- file.path( x, paste0( pwm_1, '.fimo_out.tsv.gz'))
                names( x) <- dimnames( target_region_file)[[ 'org']]
                x[ file.exists( x)]
              }
              pwm_1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
                sapply(
                  pwm_1.fimo_out_fp,
                  function( fp1) {
                    .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)}),
                select = fimo_out_ci_wanted)
              if( ! pwm_1.fimo_out[, .N]) {
                .wk[[ 'sys']]( c( 'touch', .wk[[ 'sys_safe_file_path']]( fp2)))
                next
              }
              data.table::setnames( pwm_1.fimo_out, c( names( .wk[[ 'dt_fread']]( pwm_1.fimo_out_fp[ 1], nrows = 0, cn = 1))[ fimo_out_ci_wanted]))
              #1 每个区域取p值最小的一行
              data.table::setorderv( pwm_1.fimo_out)
              pwm_1.fimo_out <- pwm_1.fimo_out[ `p-value` < p_value_cutoff, .SD[ 1], by = sequence_name]
              #1#
              pwm_1.fimo_out[, 'gene' := tolower( .wk[[ 're']]( sequence_name, '[^\\|]+'))]
              data.table::set( org_orth, , 'targeted', org_orth[[ 'ortholog-gene']] %in% pwm_1.fimo_out[[ 'gene']])
              cmm_score <- org_orth[ c( targeted), {
                sum( org_other %in% `ortholog-species`)
              }, by = `#query-gene`]
              cmm_score <- cmm_score[ `#query-gene` %in% pwm_1.fimo_out[, gene]]
              data.table::setnames( cmm_score, 'V1', 'score')
              { # p值，q值
                ## gene_notTargeted <- setdiff( org_gene[[ org_centric]][, V1], pwm_1.fimo_out[, gene])
                ## gene2sample <- gene_notTargeted
                { # @_1/12/01@
                  ## <<_2_01_12_173808>>
                  if(0){
                    gene_group <- .wk[[ 'acc']]()
                    org_orth[, 'not_grouped' := TRUE]
                    while( org_orth[, any( not_grouped)]) {
                      m <- org_orth[ which( not_grouped)[ 1], `#query-gene`]
                      while( 1) {
                        l1 <- length( m)
                        m <- union( m, org_orth[ m, on = '#query-gene', `ortholog-gene`])
                        m <- union( m, org_orth[ m, on = 'ortholog-gene', `#query-gene`])
                        if( length( m) == l1) {
                          a <- org_orth[, intersect( m, `#query-gene`)]
                          gene_group[[ 'add']]( a)
                          org_orth[ `#query-gene` %in% a]
                          break
                        }
                      }
                    }
                  }
                  a <- org_orth[ `#query-gene` %in% pwm_1.fimo_out[, gene], {
                    k <- sum( targeted)
                    if( k) {
                      p <- mean( setdiff( org_gene[[ `ortholog-species`]][[ 'V1']], `ortholog-gene`) %in% pwm_1.fimo_out[, gene])
                      if( .N > 1) 1 - pbinom( k - 1, .N, p) else p
                    }
                  }, by = list( `#query-gene`, `ortholog-species`)]
                  p <- a[, {
                    fisher_stat <- - sum( log( V1)) * 2
                    list( 'p_value' = pchisq( fisher_stat, df = 2 * .N, lower.tail = FALSE))
                  }, by = `#query-gene`]
                  if(0){
                    p[, q_value := p.adjust( p_value, 'fdr')]
                    a[, 'q_value' := p.adjust( V1, 'fdr')]
                    p <- a[, prod( p.adjust( V1, 'fdr')), by = `#query-gene`]
                    p <- a[, prod( V1), by = `#query-gene`]
                    p[, sum( p.adjust( V1, 'fdr') < .06)]
                  }
                }
                cmm_score[ p, on = '#query-gene', 'p_value' := i.p_value]
                cmm_score[, 'q_value' := p.adjust( p_value, 'fdr')]
                if(0){
                  all( cmm_score[[ '#query-gene']] == p[[ '#query-gene']])
                  cmm_score[ p[, `#query-gene`], on = '#query-gene']
                  cmm_score[ ! `#query-gene` %in% p[, `#query-gene`]]
                  g1 <- 'glyma.01g000600'
                  g1 %in% pwm_1.fimo_out[, gene]
                  cmm_score[ p_value < .05]
                  cmm_score[ q_value < .1]
                  cmm_score[ q_value < .05]
                  cmm_score[ q_value > 0, min( q_value)]
                  cmm_score[ p_value > 0, min( p_value)]
                  cmm_score[ p_value == .004, .N]
                  cmm_score[ score == 0, .N]
                }
                .wk[[ 'dt_fwrite']]( cmm_score, fp2)
                fp2
              }
            }
          })
          {
            file.path( score_fp2, paste0( pwm_1, '.', region_1, '.by_pbinom.tsv.gz'))
            file_in <- .wk[[ 'list_file']]( score_fp2, 'by_pbinom')
            dt1 <- .wk[[ 'dt_fread']]( file_in[ 1])
            dt1[ q_value < .2, .N]
            a <- .wk[[ 'do_list']]( file_in, \( x) {
              .wk[[ 'hs.msg']]( x)
              dt1 <- .wk[[ 'dt_fread']]( x)
              .wk[[ 'base_browser']]( '_2_01_28_193443')
              r <- if( dt1[, .N]) c( dt1[ q_value < .05, .N], dt1[ q_value < .1, .N], dt1[ q_value < .2, .N]) else c( 0, 0, 0)
              as.list( r)
            })
            r <- data.table::rbindlist( unname( a))
            data.table::setnames( r, paste0( 'N(fdr<', c( '0.05', '0.1', '0.2'), ')'))
            #r[, 'PWM' := ]
            basename( file_in)
            r[, .wk[[ 'colMean']]( .SD), .SDcols = patterns( '^N')]
            r[, .wk[[ 'colMedian']]( .SD), .SDcols = patterns( '^N')]
            r[, summary( .SD), .SDcols = patterns( '^N')]
            r[, summary( `N(fdr<0.1)`)]
            .wk[[ 'xls_write']](r, 'ranmdom50pwm.靶基因数目.xlsx')
            getwd()
            .wk[[ 'file_rsync']]('/media/sda1/wk/work/xm/_1/06/24/230251/cmm/ranmdom50pwm.靶基因数目.xlsx', dry = 0)
          }
          { # 输出靶基因 <<_1_10_22_234323>>
            pwm_target <- .wk[[ 'do_list']]( dimnames( target_region_file)[[ 'region']], function( x) {
              File <- .wk[[ 'list_file']]( score_fp2, ms = x)
              names( File) <- .wk[[ 'sub']]( basename( File), paste0( '.', x, '.tsv.gz'), fixed = 1)
              r <- .wk[[ 'do_list']]( File, function( file_1) {
                if( file.size( file_1) == 0) return()
                a <- .wk[[ 'dt_fread']]( file_1)
                a[ q_value < .05, `#query-gene`]
              })
              r <- .wk[[ 'get_fun']]( 'from_list._1_10_22_222000')( r, top_name = 'pwm')
              data.table::setnames( r, 'V1', 'target')
            })
            .wk[[ 'xls_write']]( pwm_target, 'pwm_target.xlsx')
            { # @_1/10/28@ pwm => tf
              motif_TF_fp <- file.path( dirname( .wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')()), 'motif_TF.txt')
              .wk[[ 'sys_head']]( motif_TF_fp)
              motif_TF <- .wk[[ 'dt_fread']]( motif_TF_fp, cn = 0)
              list( motif_TF[ pwm_target[[ 1]][, pwm], on = 'V1', V2, mult = 'all'], )
              .wk[[ 'do_list']]( names( pwm_target), function( Region) {
                for( pwm1 in pwm_target[[ Region]][, unique( pwm)]) {
                  file_in <- file.path( target_region_file.folder( target_region_file[[ org_centric, Region]]), paste0( pwm1, '.fimo_out.tsv.gz'))
                  .wk[[ 'base_browser']]( '_1_11_09_101847')
                  pwm1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
                    sapply(
                      file_in,
                      function( fp1) {
                        .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)}),
                    select = fimo_out_ci_wanted)
                  data.table::setnames( pwm1.fimo_out, c( names( .wk[[ 'dt_fread']]( file_in, nrows = 0, cn = 1))[ fimo_out_ci_wanted]))
                  #1 每个区域取p值最小的一行
                  data.table::setorderv( pwm1.fimo_out)
                  pwm1.fimo_out <- pwm1.fimo_out[ `p-value` < p_value_cutoff, .SD[ 1], by = sequence_name]
                  #
                  pwm1.fimo_out[, 'gene' := tolower( .wk[[ 're']]( sequence_name, '[^\\|]+'))]
                  .wk[[ 'base_browser']]( '_1_10_29_142455')
                  pwm_target[[ Region]][ pwm1, on = 'pwm']
                  pwm1_target <- pwm_target[[ Region]][ pwm1, on = 'pwm', target]
                  pwm1.fimo_out[ list( pwm1_target), on = 'gene']
                  pwm_target[[ Region]][ pwm1, on = 'pwm', p_value := 1]
                }
              })
              tf_target <- .wk[[ 'do_list']]( pwm_target, function( x) {
                r <- list( motif_TF[ x[, pwm], on = 'V1', V2, mult = 'all'], x[, target])
                data.table::setDT( r)
                data.table::setnames( r, c( 'TF', 'target'))
              })
            }
            .wk[[ 'sys_ls']]()
            .wk[[ 'file_rsync']]( '/media/sda1/wk/work/xm/_1/06/24/230251/cmm/pwm_target.xlsx', dry = 0)
            .wk[[ 'file_rsync']]( '/media/sda1/wk/work/xm/_1/06/24/230251/cmm/pwm_target.xlsx', ssh = '')
          }
          { # 统计
            a <- sapply( .wk[[ 'list_file']]( 'score'), function( fp1) {
              if( file.size( fp1) > 0) {
                a <- .wk[[ 'dt_fread']]( fp1)
                b <- a[, V4[ 1], by = V1]
                .wk[[ 'dt_setnames']]( b, c( 'orth_grp', 'p_value'))
                b[, 'q_value' := p.adjust( p_value, 'fdr')]
                c( b[, sum( q_value < .05)], b[ a, sum( q_value < .05), on = list( orth_grp == V1)])
              } else c( 0, 0)
            })
            apply( a, 1, summary)
            ## Min.      0.0000   0.00000
            ## 1st Qu.   2.0000   3.00000
            ## Median    5.0000   7.00000
            ## Mean     17.6973  31.01959
            ## 3rd Qu.  19.0000  34.00000
            ## Max.    214.0000 430.00000
          }
        }
      }
    }
  })
}
