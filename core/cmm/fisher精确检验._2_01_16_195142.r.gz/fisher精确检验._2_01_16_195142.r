#
function() {
  wd <- .wk[[ 'task_folder']]( '_2_01_16_195142')
  fimo_fp <- .wk[[ 'get_fun']]( '用conda/找软件._1_07_12_091131')( 'fimo')
  
  .wk[[ 'get_fun']]( '软件版本控制._1_07_13_202140')( fimo_fp, '_1_07_15_134113')
  .wk[[ 'with_wd']]( wd, {
    setwd( wd)
    org_centric <- 'osa'#'gma'#'ath''华占'
    pwm_file <- switch(
      org_centric,
      'gma' = local({
        pwm_folder <- .wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')( org = '大豆')
        .wk[[ 'list_file']]( pwm_folder)
        #
      }),
      'osa' = {
        #.wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')( org = '水稻')
        .wk[[ 'get_fun']]( '修pwm._2_02_12_001129')()
      }
    )
    if(0){
      .wk[[ 'sys_less']](pwm_file[1])
      .wk[[ 'sys']]( c( .wk[[ 'sys_safe_file_path']]( fimo_fp), '--help'))
      .wk[[ 'sys_less']]('~/work/xm/_1/06/24/230251/pwm/gma_motif/M00008_2.00.txt')
    }
    target_region_file <- .wk[[ 'get_fun']]( '目标区域/_1_07_11_095820')()
    if(0){
      .wk[[ 'file_rm']]( unlist( target_region_file[ 'osa',]))
      .wk[[ 'sys_ls']]( unlist( target_region_file[ 'osa',]))
      .wk[[ 'sys_less']]('~/work/xm/_1/06/24/230251/目标区域/2000_tss_500.osa.fa.gz')
    }

    # 用fimo
    target_region_file.folder <- function( x) {
      .wk[[ 'sub']]( basename( x), '\\.fa(\\.gz)?$')
    }

    fimo_out_folder_fun <- function( org_centric, target_region_file)
      do.call(
        .wk[[ 'folder_path']],
        as.list(
          c( target_region_file.folder( target_region_file),
            if( org_centric != 'gma')
              paste0( org_centric, '_pwm'))))
    for( target_region_file1 in target_region_file[, '2000_tss_500']) # 生成每个物种的目标区域的每个pwm的结果 <<_1_08_08_125927>>
      .wk[[ 'get_fun']]( 'fimo/处理meme文件._2_02_16_121520')(
        meme_fp = pwm_file,
        fa_fp = target_region_file1,
        fimo_fp = fimo_fp,
        folder2 = fimo_out_folder_fun( org_centric = org_centric, target_region_file = target_region_file1)
      )
    if(0){
      .wk[[ 'sys_ls']]( .wk[[ 'sys']]( c( 'ag -g', 'M00008_2'), intern = 1))
      .wk[[ 'sys_ls']]( .wk[[ 'sys']]( c( 'ag -g', 'LOC_Os01g03720'), intern = 1))
      .wk[[ 'sys_less']]( '/home/wk/work/xm/_1/06/24/230251/日本晴pwm/final_merged_motifs_fixed.meme')
      lapply( .wk[[ 'list_file']]( wj = 0, ms = '^2000_tss_500'), function( folder_1) {
        wd_1 <- .wk[[ 'list_file']]( folder_1, wj = 0)
        if( length( wd_1) != 1)
          .wk[[ 'base_browser']]( '_2_02_27_155334')
        .wk[[ 'with_wd']]( wd_1, {
          fp <- .wk[[ 'list_file']]( ms = '\\.tsv\\.gz$')
          for( fp1 in fp) {
            if( .wk[[ 'grepl']]( fp1, '\\.fimo_out\\.'))
              next
            fp2 <- .wk[[ 'file_name']]( fp1, append = 'fimo_out', extN = 2, append_sep = '.')
            if( ! file.exists( fp2))
              file.rename( fp1, fp2)
          }
        })
      })
    }

    { # cmm
      # 物种
      org_v <- .wk[[ 'get_fun']]( '物种._1_06_24_214742')()
      org_other <- .wk[[ '%rm%']]( org_v, org_centric)
      .wk[[ 'say']]( org_other, sep = ', ')

      # 每个物种的所有基因
      gene_folder <- .wk[[ 'get_fun']]( '基因/_1_06_22_155510')()
      org_gene <- list()
      org_gene[[ org_centric]]
      org1 <- org_centric
      for( org1 in org_v) {
        if( org1 == '华占') { # @_2/02/21@
          a <- file.path( .wk[[ 'get_fun']]( '水稻/基因组._2_02_16_141026')(), 'HZ.gtf.gz')
          a <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( .wk[[ 'fill_list']]( 3, 'transcript'), fp = a, ci2 = 9)
        } else {
          a <- file.path( gene_folder, paste0( 'annotation.all_transcripts.all_features.', org1, '.gff3.gz'))
          a <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( .wk[[ 'fill_list']]( 3, 'gene'), fp = a, ci2 = 9)
        }
        .wk[[ 'dt_reset_name']]( a)
        a[, 'V1' := tolower( .wk[[ 'str_trim']]( .wk[[ 're']]( V1, '(?i)(?<=gene_id[ =])[^;]+'), '"'))]
        org_gene[[ org1]] <- a
      }
      sum( sapply( org_gene, function( x) x[, .N]))

      # org_orth，直系同源关系
      orth_fp <- file.path( gene_folder, paste0( 'integrative_orthology.', org_centric, '.tsv.gz'))
      org_orth <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( list( 'BHIF' = 1, 'ORTHO' = 1, 'ortholog-species' = org_other), orth_fp, head = 1, skip = 1, exclude_ci1 = c( 'BHIF', 'ORTHO'))
      for( cn in c( '#query-gene', 'ortholog-gene')) # 基因名称改为小写
        data.table::set( org_orth, , cn, tolower( org_orth[[ cn]]))
      {
        all( org_orth[[ '#query-gene']] %in% org_gene[[ org_centric]][, V1])
        for( org1 in org_orth[, unique( `ortholog-species`)])
          if( ! all( org_orth[ org1, on = 'ortholog-species', `ortholog-gene`] %in% org_gene[[ org1]][, V1]))
            stop( '[_1_10_08_130115]')
      }

      { # 每次处理1个pwm @_1_08_02_222524@
        pwm_db <- {
          a <- lapply( target_region_file, function( x) {
            x <- target_region_file.folder( x)
            x <- .wk[[ 'list_file']]( x, F = 0)
            .wk[[ 'sub']]( x, '(?i)\\.fimo_out\\.tsv\\.gz$')
          })
          sort( unique( unlist( a)))
        }
        pwm_db <- .wk[[ 'get_fun']]( 'meme/提取pwm号._2_02_16_105336')( pwm_file)
        length( pwm_db) # 1480、645
        pwm_target_fun <- function( pwm1, p_value_cutoff) {
          fimo_out_ci_wanted <- c( 1, 6)
          pwm1.fimo_out_fp <- {
            x <- sapply( target_region_file[, region_1], function( x) {
              #target_region_file.folder( x)
              fimo_out_folder_fun( org_centric = org_centric, target_region_file = x)
            })
            #x <- file.path( x, paste0( pwm1, '.fimo_out.tsv.gz'))
            x <- sapply( x, function( x) {
              r <- .wk[[ 'list_file']]( x, pwm1)
              if( length( r) != 1)
                .wk[[ 'base_browser']]( '_2_02_23_131523')
              r
            })
            names( x) <- dimnames( target_region_file)[[ 'org']]
            x[ file.exists( x)]
          }
          pwm1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
            sapply(
              pwm1.fimo_out_fp,
              function( fp1) {
                .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)}),
            select = fimo_out_ci_wanted
          )
          pwm1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
            sapply(
              pwm1.fimo_out_fp,
              function( fp1) {
                .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)})
          )
          if( ! pwm1.fimo_out[, .N])
            return()
          data.table::setnames( pwm1.fimo_out, names( .wk[[ 'dt_fread']]( pwm1.fimo_out_fp[ 1], nrow = 0, cn = 1)))
          data.table::setorderv( pwm1.fimo_out, c( 'sequence_name', 'p-value'))
          pwm1.fimo_out <- pwm1.fimo_out[ `p-value` < p_value_cutoff, .SD[ 1], by = sequence_name]
          pwm1.fimo_out[, 'gene' := tolower( .wk[[ 're']]( sequence_name, '[^\\|]+'))]
        }
        p_value_cutoff <- 1e-4
        score_fp2 <- 'score/integrative-orthology/nonTarget' # @_1/10/08@
        .wk[[ 'folder_path']]( score_fp2)
        .wk[[ 'sys_ls']]( score_fp2)
        .wk[[ 'sys_head']]( file.path( score_fp2, 'M11491_2.00.2000_tss_500.tsv.gz'))
        pwm_1 <- 'M00216_2.00'
        pwm_1 <- 'M00008_2.00'
        ranmdom50pwm <- .wk[[ 'eval_lazy']]({
          sort( sample( pwm_db, 50))
        }, file = 'ranmdom50pwm.rd')

        # gene_group
        gene_group <- .wk[[ 'eval_lazy']](
          {
            gene_group <- .wk[[ 'acc']]()
            org_orth[, 'not_grouped' := TRUE]
            while( print( org_orth[, sum( not_grouped)])) {
              m <- org_orth[ match( TRUE, not_grouped, nomatch = 0), `#query-gene`]
              while( 1) {
                l1 <- length( m)
                m <- union( m, org_orth[ m, on = '#query-gene', `ortholog-gene`])
                m <- union( m, org_orth[ m, on = 'ortholog-gene', `#query-gene`])
                m <- setdiff( m, NA)
                if( length( m) == l1) {
                  gene_group[[ 'add']]( m)
                  org_orth[ `#query-gene` %in% m, 'not_grouped' := FALSE]
                  org_orth[ `ortholog-gene` %in% m, 'not_grouped' := FALSE]
                  break
                }
              }
            }
            gene_group
          },
          file = ( function( org_centric) {
            r <- 'gene_group.rd'
            if( org_centric != 'gma')
              r <- .wk[[ 'file_name']]( r, append = org_centric, append_sep = '.')
            r
          })( org_centric)
        )
        
        gene_group <- gene_group[['get']]()
        names( gene_group) <- sapply( gene_group, \( x) {
          digest::digest( sort( na.omit( x)))
        }) # @_2/01/25@
        anyDuplicated( names( gene_group))

        # fisher精确检验的数据准备
        dt_us1s2 <- data.table::rbindlist( org_gene)
        data.table::setnames( dt_us1s2, 'V1', 'gene')
        data.table::set( dt_us1s2, , 'org', rep( names( org_gene), sapply( org_gene, '[', , .N)))

        region2do <- intersect( '2000_tss_500', dimnames( target_region_file)[[ 'region']])

        lapply( seq_along( pwm_db), function( pwm_1_i) {
          pwm_1 <- pwm_db[ pwm_1_i]
          for( region_1 in region2do) {

            fp2 <- file.path( score_fp2, paste0( pwm_1, '.', region_1, '.by_fisher.tsv.gz'))
            if( file.exists( fp2))
              next
            .wk[[ 'hs.msg']]( fp2)

            pwm_1.fimo_out <- pwm_target_fun( pwm = pwm_1, p_value_cutoff = p_value_cutoff)
            if( is.null( pwm_1.fimo_out)) {
              .wk[[ 'sys']]( c( 'touch', .wk[[ 'sys_safe_file_path']]( fp2)))
              next
            }

            if(0){ #1 考虑p值阈值
              p_value_cutoff_forThisPWM <- min( 1e-4, pwm_1.fimo_out[, quantile( `p-value`, .1)])
              pwm_1.fimo_out[ `p-value` <= p_value_cutoff_forThisPWM, .N]
              mean( org_gene[[ org_centric]][[ 'V1']] %in% pwm_1.fimo_out[ `p-value` < p_value_cutoff_forThisPWM, gene])
              pwm_1.fimo_out[ p.adjust( `p-value`, 'fdr') < .05, .N]
              pwm_1.fimo_out[, summary( `p-value`)]
              pwm_1.fimo_out[, .N]
              pwm_1.fimo_out
              pwm_1.fimo_out <- pwm_1.fimo_out[ `p-value` < p_value_cutoff, .SD[ 1], by = sequence_name]
              pwm_1.fimo_out <- pwm_1.fimo_out[, .SD[ 1], by = sequence_name]
              data.table::set( org_orth, , 'targeted', org_orth[[ 'ortholog-gene']] %in% pwm_1.fimo_out[[ 'gene']])
              #1#
            }

            { # p值，q值

              org_orth_targeted <- org_orth[ `#query-gene` %in% pwm_1.fimo_out[, gene]]
              .wk[[ 'pipe-back']]( gene_group, x[ .wk[[ 'get_fun']]( '拆表_函数_函数2._2_01_17_222256')( x, function( x) x %in% org_orth_targeted[, `#query-gene`])])

              p <- .wk[[ 'mclapply']]( seq_along( gene_group), function( i) {
                .wk[[ 'hs.msg']]( i)
                g1 <- gene_group[[ i]]
                g1.org <- org_orth_targeted[ `ortholog-gene` %in% g1, union( `ortholog-species`, org_centric)]
                dt_us1s2[ org %in% g1.org, {
                  test <- fisher.test( table( in_family = gene %in% g1, targeted = gene %in% pwm_1.fimo_out[, gene]), alternative = 'greater')
                  test[ c( 'estimate', 'p.value')]
                }]
              })
              names( p) <- names( gene_group)
              p <- data.table::rbindlist( p)
              p[, 'q_value' := p.adjust( p.value, 'fdr')]
              p[, 'gene_group_code' := names( gene_group)]

              .wk[[ 'dt_fwrite']]( p, fp2)
            }
          }
        })
        { # 输出靶基因 <<_1_10_22_234323>>
          pwm_target <- .wk[[ 'do_list']]( region2do, function( x) {
            File <- .wk[[ 'list_file']]( score_fp2, ms = x)
            File <- .wk[[ 'grepV']]( File, 'by_fisher')
            names( File) <- { # pwm
              a <- .wk[[ 'sub']]( basename( File), '.tsv.gz', fixed = 1)
              a <- .wk[[ 'sub']]( a, '.by_fisher', fixed = 1)
              .wk[[ 'sub']]( a, paste0( '.', x), fixed = 1)
            }
            r <- .wk[[ 'do_list']]( File, function( file_1) {
              if( .wk[[ 'file_empty_p']]( file_1)) return()
              a <- .wk[[ 'dt_fread']]( file_1)
              if( ! a[ q_value < fdr_cutoff, .N]) return()
              list( 'target' = intersect( .wk[['base_unlist']]( gene_group[ a[ q_value < fdr_cutoff, gene_group_code]]), org_gene[[ org_centric]][[ 'V1']]))
            })
            data.table::rbindlist( r, idcol = 'pwm')
          })
          lapply( pwm_target, function( x) {
            x[, .N, by = pwm][, summary( N)]
          })
          { # 基因的最小fimo p值
            for( region_1 in names( pwm_target)) {
              for( pwm1 in pwm_target[[ region_1]][, unique( pwm)]) {
                .wk[[ 'hs.msg']](pwm1)
                pwm1_target <- pwm_target_fun( pwm = pwm1, p_value_cutoff = p_value_cutoff)
                a <- intersect(
                  pwm_target[[ region_1]][ pwm1, on = 'pwm', target],
                  pwm1_target[, gene]
                )
                pwm_target[[ region_1]][ list( 'pwm' = pwm1, 'target' = a), on = c( 'pwm', 'target'), 'fimo_pValue' := pwm1_target[ a, on = 'gene', `p-value`]]
              }
              .wk[[ 'pipe-back']]( pwm_target[[ region_1]], x[ ! is.na( fimo_pValue)])
            }
          }
          { # pwm > 转录因子
            motif_TF_fp <- file.path( dirname( .wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')()), 'motif_TF.txt')
            motif_TF <- .wk[[ 'dt_fread']]( motif_TF_fp, cn = 0)
            motif_TF[ pwm_target[[ 1]][, pwm], on = 'V1', V2, mult = 'all']
            for( n1 in names( pwm_target)) {
              data.table::set( pwm_target[[ n1]], , 'pwm', motif_TF[ pwm_target[[ n1]][[ 'pwm']], on = 'V1', V2, mult = 'all'])
              data.table::setnames( pwm_target[[ n1]], 'pwm', 'tf')
            }
          }
          .wk[[ 'xls_write']]( pwm_target, .wk[[ 'file_name']]( 'cPWM_target.xlsx', append = org_centric))
          normalizePath( .wk[[ 'file_name']]( 'cPWM_target.xlsx', append = org_centric))
          
          org_centric
          #.wk[[ 'file_rsync']]('/media/sda1/wk/work/xm/_1/06/24/230251/cmm/cPWM_target.xlsx',dry=0)
          #.wk[[ 'file_rsync']]('/media/sda1/wk/work/xm/_1/06/24/230251/cmm/cPWM_target_osa.xlsx',dry=0)
          { # @_1/10/28@ pwm => tf
            motif_TF_fp <- file.path( dirname( .wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')()), 'motif_TF.txt')
            .wk[[ 'sys_head']]( motif_TF_fp)
            motif_TF <- .wk[[ 'dt_fread']]( motif_TF_fp, cn = 0)
            list( motif_TF[ pwm_target[[ 1]][, pwm], on = 'V1', V2, mult = 'all'], )
            .wk[[ 'do_list']]( names( pwm_target), function( Region) {
              for( pwm1 in pwm_target[[ Region]][, unique( pwm)]) {
                file_in <- file.path( target_region_file.folder( target_region_file[[ org_centric, Region]]), paste0( pwm1, '.fimo_out.tsv.gz'))
                .wk[[ 'base_browser']]( '_1_11_09_101847')
                pwm1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
                  sapply(
                    file_in,
                    function( fp1) {
                      .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)}),
                  select = fimo_out_ci_wanted)
                data.table::setnames( pwm1.fimo_out, c( names( .wk[[ 'dt_fread']]( file_in, nrows = 0, cn = 1))[ fimo_out_ci_wanted]))
                #1 每个区域取p值最小的一行
                data.table::setorderv( pwm1.fimo_out)
                pwm1.fimo_out <- pwm1.fimo_out[ `p-value` < p_value_cutoff, .SD[ 1], by = sequence_name]
                #
                pwm1.fimo_out[, 'gene' := tolower( .wk[[ 're']]( sequence_name, '[^\\|]+'))]
                .wk[[ 'base_browser']]( '_1_10_29_142455')
                pwm_target[[ Region]][ pwm1, on = 'pwm']
                pwm1_target <- pwm_target[[ Region]][ pwm1, on = 'pwm', target]
                pwm1.fimo_out[ list( pwm1_target), on = 'gene']
                pwm_target[[ Region]][ pwm1, on = 'pwm', p_value := 1]
              }
            })
            tf_target <- .wk[[ 'do_list']]( pwm_target, function( x) {
              r <- list( motif_TF[ x[, pwm], on = 'V1', V2, mult = 'all'], x[, target])
              data.table::setDT( r)
              data.table::setnames( r, c( 'TF', 'target'))
            })
          }
          .wk[[ 'sys_ls']]()
          .wk[[ 'file_rsync']]( '/media/sda1/wk/work/xm/_1/06/24/230251/cmm/pwm_target.xlsx', dry = 0)
          .wk[[ 'file_rsync']]( '/media/sda1/wk/work/xm/_1/06/24/230251/cmm/pwm_target.xlsx', ssh = '')
        }
        { # 统计
          { # @_2/01/26@
            fp <- .wk[[ 'list_file']](score_fp2, 'by_fisher.*\\.tsv.gz$')
            fdr_cutoff <- .05
            a <- .wk[['do_list']](fp, \(fp1) {
              .wk[['hs.msg']](fp1)
              if(!length(.wk[['sys']](c('gzip -cd', .wk[['sys_safe_file_path']](fp1), '|head'), intern=1)))
                return(0)
              dt1 <- .wk[['dt_fread']](fp1)
              x <- dt1[q_value < fdr_cutoff, gene_group_code]
              if(length(x)) {
                x <- unlist(gene_group[dt1[q_value < fdr_cutoff, gene_group_code]])
                length( x[x %in% org_gene[[org_centric]][['V1']]])
              } else 0
            })
            a <- .wk[[ 'base_unlist']](a)
            summary( a)
            .wk[['say']](paste(sort(a), collapse=','))
            ls( .wk, pattern = 'unlist')
          }
          a <- sapply( .wk[[ 'list_file']]( 'score'), function( fp1) {
            if( file.size( fp1) > 0) {
              a <- .wk[[ 'dt_fread']]( fp1)
              b <- a[, V4[ 1], by = V1]
              .wk[[ 'dt_setnames']]( b, c( 'orth_grp', 'p_value'))
              b[, 'q_value' := p.adjust( p_value, 'fdr')]
              c( b[, sum( q_value < .05)], b[ a, sum( q_value < .05), on = list( orth_grp == V1)])
            } else c( 0, 0)
          })
          apply( a, 1, summary)
          ## Min.      0.0000   0.00000
          ## 1st Qu.   2.0000   3.00000
          ## Median    5.0000   7.00000
          ## Mean     17.6973  31.01959
          ## 3rd Qu.  19.0000  34.00000
          ## Max.    214.0000 430.00000
        }
      }
    }
  })
}
