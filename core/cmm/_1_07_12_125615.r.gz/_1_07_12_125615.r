#
function() {
  wd <- .wk[[ 'task_folder']]( '_1_07_12_125615')
  # .wk[[ 'sys_ls']]( wd)
  fimo_fp <- .wk[[ 'get_fun']]( '用conda/找软件._1_07_12_091131')( 'fimo')
  .wk[[ 'get_fun']]( '软件版本控制._1_07_13_202140')( fimo_fp, '_1_07_15_134113')
  .wk[[ 'with_wd']]( wd, {
    setwd( wd)
    pwm_folder <- .wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')()
    pwm_file <- .wk[[ 'list_file']]( pwm_folder)
    target_region_file <- .wk[[ 'get_fun']]( '目标区域/_1_07_11_095820')() # <<_1_08_11_221531>>
    # .wk[[ 'sys_head']]( target_region_file[[ 1]])
    # 【不行】 pwm_file <- .wk[['sys_cmd']]( c( '<(', 'find', .wk[['sys_safe_file_path']]( pwm_folder), '-type f', '| xargs -I{} cat {}', ')'))

    # 用fimo
    target_region_file.folder <- function( x) {
      .wk[[ 'sub']]( basename( x), '\\.fa(\\.gz)?$')
    }
    for( target_region_file1 in target_region_file) { # 生成每个物种的目标区域的每个pwm_file的结果 <<_1_08_08_125927>>
      .wk[[ 'mclapply']]( pwm_file, function( pwm1_file) {
        fp2 <- .wk[[ 'file_path']](
          target_region_file.folder( target_region_file1),
          .wk[[ 're']]( base::basename( pwm1_file), '\\.[^\\.]+$', '.fimo_out.tsv.gz')
        )
        if( base::file.exists( fp2)) return()
        .wk[[ 'sys']]( base::c(
          .wk[[ 'sys_safe_file_path']]( fimo_fp),
          '--text',
          .wk[[ 'sys_safe_file_path']]( pwm1_file),
          .wk[[ 'sys_cat_text']]( target_region_file1, as_file = 1),
          '| cut -f3-',
          '| gzip >', .wk[[ 'sys_safe_file_path']]( fp2))
        )
      }, nc = 10)
      if(0)for( pwm1_file in pwm_file) {
        fp2 <- .wk[['file_path']]( .wk[['sub']]( basename( target_region_file1), '\\.fa(\\.gz)?$'), .wk[['re']]( basename( pwm1_file), '\\.[^\\.]+$', '.fimo_out.tsv.gz'))
        if( file.exists( fp2)) next
        .wk[['with_msg']](
          fp2,
          .wk[['sys']]( c(
            .wk[['sys_safe_file_path']]( fimo_fp),
            '--text',
            .wk[['sys_safe_file_path']]( pwm1_file),
            '<( gzip -cd', .wk[['sys_safe_file_path']]( target_region_file1), ')',
            '| cut -f3-',
            '| gzip >', .wk[['sys_safe_file_path']]( fp2))
          )
        )
      }
    }

    { # cmm
      # 物种
      org_v <- .wk[[ 'get_fun']]( '物种._1_06_24_214742')()
      org_centric <- 'gma'#'ath'
      org_other <- .wk[[ '%rm%']]( org_v, org_centric)

      { # @_1/08/28@
        a1[, .wk[[ 'dt_uniqN']]( target_gene), by = `#TF`][, summary( V1)]
      }

      { # 每个物种的所有基因
        gene_folder <- .wk[[ 'get_fun']]( '基因/_1_06_22_155510')()
        org_gene <- list()
        for( org1 in org_v) {
          a <- file.path( gene_folder, paste0( 'annotation.all_transcripts.all_features.', org1, '.gff3.gz'))
          a <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( .wk[[ 'fill_list']]( 3, 'gene'), fp = a, ci2 = 9)
          .wk[[ 'dt_reset_name']]( a)
          a[, 'V1' := tolower( .wk[[ 're']]( V1, '(?i)(?<=gene_id=)[^;]+'))]
          org_gene[[ org1]] <- a
        }
      }
      { # @_1/08/22@ 用第2个同源基因信息来源 <<_1_08_22_210611>>
        orth_fp <- file.path( gene_folder, paste0( 'integrative_orthology.', org_centric, '.tsv.gz'))
        .wk[[ 'sys_head']]( orth_fp)
        org_orth <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( list( 'BHIF' = 1, 'ORTHO' = 1, 'ortholog-species' = org_other), orth_fp, head = 1, skip = 1, exclude_ci1 = c( 'BHIF', 'ORTHO'))
        for( cn in c( '#query-gene', 'ortholog-gene')) { # 基因名称改为小写
          data.table::set( org_orth, , cn, tolower( org_orth[[ cn]]))
        }
        {
          all( org_orth[[ '#query-gene']] %in% org_gene[[ org_centric]][, V1])
          for( org1 in org_orth[, unique( `ortholog-species`)]) {
            if( ! all( org_orth[ org1, on = 'ortholog-species', `ortholog-gene`] %in% org_gene[[ org1]][, V1])) {
              stop( '[_1_10_08_130115]')
            }
          }
        }
        { # 每次处理1个pwm @_1_08_02_222524@
          pwm_db <- {
            a <- lapply( target_region_file, function( x) {
              x <- target_region_file.folder( x)
              x <- .wk[[ 'list_file']]( x, F = 0)
              .wk[[ 'sub']]( x, '(?i)\\.fimo_out\\.tsv\\.gz$')
            })
            sort( unique( unlist( a)))
          }
          length( pwm_db) # 1480
          fimo_out_ci_wanted <- c( 1, 6)
          p_value_cutoff <- 1e-4
          score_fp2 <- 'score/integrative-orthology'
          score_fp2 <- 'score/integrative-orthology/nonTarget' # @_1/10/08@
          .wk[[ 'folder_path']]( score_fp2)
          .wk[[ 'sys_ls']]( score_fp2)
          .wk[[ 'sys_head']]( file.path( score_fp2, 'M11491_2.00.2000_tss_500.tsv.gz'))
          pwm_1 <- 'M00216_2.00'
          pwm_1 <- 'M00008_2.00'
          ranmdom50pwm <- .wk[[ 'eval_lazy']]({
            sort( sample( pwm_db, 50))
          }, file = 'ranmdom50pwm.rd')
          for( pwm_1_i in seq_along( ranmdom50pwm)) {
            pwm_1 <- ranmdom50pwm[ pwm_1_i]
            for( region_1 in intersect( '2000_tss_500', dimnames( target_region_file)[[ 'region']])) {
              fp2 <- file.path( score_fp2, paste0( pwm_1, '.', region_1, '.tsv.gz'))
              #if( file.exists( fp2)) next
              if(0){
                .wk[[ 'sys_head']]( fp2)
                .wk[[ 'sys_ls1']]( fp2)
                a <- .wk[[ 'dt_fread']]( fp2)
                a[, min( p_value)]
                a[, min( q_value)]
                a[ q_value < .1, .N]
              }
              .wk[[ 'hs.msg']]( fp2)
              pwm_1.fimo_out_fp <- {
                x <- sapply( target_region_file[, region_1], function( x) {
                  target_region_file.folder( x)
                })
                x <- file.path( x, paste0( pwm_1, '.fimo_out.tsv.gz'))
                names( x) <- dimnames( target_region_file)[[ 'org']]
                x[ file.exists( x)]
              }
              if(0){
                .wk[[ 'sys_head']]( pwm_1.fimo_out_fp[ org_centric])
                .wk[[ 'sys_ls']]( pwm_1.fimo_out_fp[ 1])
                .wk[[ 'sys_less']]( pwm_1.fimo_out_fp[ 1])
                file.size( pwm_1.fimo_out_fp)
                unlink( pwm_1.fimo_out_fp)
                .wk[[ 'grepV']]( pwm_file, 'M00153_2')
                .wk[[ 'sys_less']]( pwm_1.fimo_out_fp[ 1])
                ls( .wk, pattern = 'uniq')
                .wk[[ 'sys_uniq4r']]( c( 1, 1, 2, 1, 1, 3), 'last')
                pwm_1.fimo_out[, length( .wk[[ 'sys_uniq4r']]( sequence_name))]
              }
              pwm_1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
                sapply(
                  pwm_1.fimo_out_fp,
                  function( fp1) {
                    .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)}),
                select = fimo_out_ci_wanted)
              if( ! pwm_1.fimo_out[, .N]) {
                .wk[[ 'sys']]( c( 'touch', .wk[[ 'sys_safe_file_path']]( fp2)))
                next
              }
              data.table::setnames( pwm_1.fimo_out, c( names( .wk[[ 'dt_fread']]( pwm_1.fimo_out_fp[ 1], nrows = 0, cn = 1))[ fimo_out_ci_wanted]))
              #1 每个区域取p值最小的一行
              data.table::setorderv( pwm_1.fimo_out)
              pwm_1.fimo_out <- pwm_1.fimo_out[ `p-value` < p_value_cutoff, .SD[ 1], by = sequence_name]
              if(0){
                pwm_1.fimo_out[ .wk[[ 'grep']]( sequence_name, '(?i)glyma.04g038800')]
              }
              #1#
              pwm_1.fimo_out[, 'gene' := tolower( .wk[[ 're']]( sequence_name, '[^\\|]+'))]
              data.table::set( org_orth, , 'targeted', org_orth[[ 'ortholog-gene']] %in% pwm_1.fimo_out[[ 'gene']])
              cmm_score <- org_orth[ c( targeted), {
                sum( org_other %in% `ortholog-species`)
              }, by = `#query-gene`]
              if(0){
                table( cmm_score[, `#query-gene`] %in% pwm_1.fimo_out[[ 'gene']])
                if(0){ # @_2/01/11@ 和同一个'ortholog-gene'是家族成员的'#query-gene'，家族成员都一样吗？
                  org_orth[, {
                    if( .N > 1) {
                      .SD; .wk[[ 'base_browser']]( '_2_01_11_215905')
                    }
                  }, by = `ortholog-gene`]
                  a <- org_orth[ 'at1g68890', on = 'ortholog-gene', `#query-gene`]
                  a <- lapply( a, function( a) {
                    org_orth[ a, on = '#query-gene', sort( `ortholog-gene`)]
                  })
                }
                {
                  org_orth[, {
                    .wk[[ 'dt_uniqN']]( `ortholog-gene`)
                  }, by = `#query-gene`]
                  org_orth[, {
                    anyDuplicated( `ortholog-gene`)
                  }, by = `#query-gene`][, table( V1)]
                }
                table( org_orth[, unique( `#query-gene`)] %in% pwm_1.fimo_out[, unique( gene)])
                org_orth[, table( `query-species`)]
                org_orth[, table( `ortholog-species`)]
                org_orth[, .wk[[ 'dt_uniqN']]( `#query-gene`)]
                gene_1 <- 'glyma.04g038800'
                cmm_score[ gene_1, on = '#query-gene']
                pwm_1.fimo_out[ gene_1, on = 'gene']
                gene_1 %in% pwm_1.fimo_out[[ 'gene']]
                gene_1 %in% org_orth[[ '#query-gene']]
                which( org_orth[[ '#query-gene']] %in% gene_1)
                org_orth[ gene_1, on = '#query-gene']
                length( org_other)
              }
              data.table::setnames( cmm_score, 'V1', 'score')
              { # p值，q值
                ## gene_notTargeted <- setdiff( org_gene[[ org_centric]][, V1], pwm_1.fimo_out[, gene])
                ## gene2sample <- gene_notTargeted
                { # @_1/12/01@
                  ## <<_2_01_12_173808>>
                  {
                    gene_group <- .wk[[ 'acc']]()
                    org_orth[, 'not_grouped' := TRUE]
                    while( org_orth[, any( not_grouped)]) {
                      m <- org_orth[ which( not_grouped)[ 1], `#query-gene`]
                      while( 1) {
                        l1 <- length( m)
                        m <- union( m, org_orth[ m, on = '#query-gene', `ortholog-gene`])
                        m <- union( m, org_orth[ m, on = 'ortholog-gene', `#query-gene`])
                        if( length( m) == l1) {
                          a <- org_orth[, intersect( m, `#query-gene`)]
                          gene_group[[ 'add']]( a)
                          org_orth[ `#query-gene` %in% a]
                          break
                        }
                      }
                    }
                  }
                  a <- org_orth[ `#query-gene` %in% pwm_1.fimo_out[, gene], {
                    k <- sum( targeted)
                    if( k) {
                      p <- mean( setdiff( org_gene[[ `ortholog-species`]][[ 'V1']], `ortholog-gene`) %in% pwm_1.fimo_out[, gene])
                      if( .N > 1) 1 - pbinom( k - 1, .N, p) else p
                    }
                  }, by = list( `#query-gene`, `ortholog-species`)]
                  if(0){
                    b <- org_orth[ `#query-gene` %in% pwm_1.fimo_out[, gene], {
                      if( any( targeted)) {
                        p <- mean( setdiff( org_gene[[ `ortholog-species`]][[ 'V1']], `ortholog-gene`) %in% pwm_1.fimo_out[, gene])
                        list( 'p_value' = 1 - ( 1 - p) ^ .N) # 成功至少1次
                      }
                    }, by = list( `#query-gene`, `ortholog-species`)]
                  }
                  p <- a[, {
                    fisher_stat <- - sum( log( V1)) * 2
                    list( 'p_value' = pchisq( fisher_stat, df = 2 * .N, lower.tail = FALSE))
                  }, by = `#query-gene`]
                  p[, q_value := p.adjust( p_value, 'fdr')]
                  if(0){
                    {
                      p <- a[, {
                        fisher_stat <- - sum( log( V1)) * 2
                        list( 'p_value' = pchisq( fisher_stat, df = 2 * .N, lower.tail = FALSE))
                      }, by = `#query-gene`]
                      p[, q_value := p.adjust( p_value, 'fdr')]
                      p[, min( p_value)] # 0.02104861
                      p[, mean( p_value < .05) * 100] # 0.01019472
                      p[, sum( p_value < .05) * 100] # 200
                      p[, min( p.adjust( p_value, 'fdr'))] # 0.7731065
                    }
                    {
                      p <- b[, {
                        fisher_stat <- - sum( log( p_value)) * 2
                        list( 'p_value' = pchisq( fisher_stat, df = 2 * .N, lower.tail = FALSE))
                      }, by = `#query-gene`]
                      p[, min( p_value)] # 0.3570065
                    }
                    data.table::set( p, , 'N', a[, .N, by = `#query-gene`][, N])
                    p[, table( N)]
                    p[, 'q_value' := p.adjust( V1, 'fdr')]
                    p[, sum( q_value < .05)]
                    p[ N >= 10, min( p.adjust( V1, 'fdr'))]
                  }
                  a[, 'q_value' := p.adjust( V1, 'fdr')]
                  p <- a[, prod( p.adjust( V1, 'fdr')), by = `#query-gene`]
                  p[, sum( V1)]
                  p[, sum( V1 < .05)]
                  p <- a[, prod( V1), by = `#query-gene`]
                  p[, sum( p.adjust( V1, 'fdr') < .06)]
                  cmm_score_orthN <- org_orth[ `#query-gene` %in% pwm_1.fimo_out[, gene], {
                    if( any( targeted)) {
                      list( 'all' = .N, 'targeted' = sum( targeted))
                    }
                  }, by = list( `#query-gene`, `ortholog-species`)]
                  cmm_score_orthN[ which.max( all)]
                  
                  org_orth[ `#query-gene` %in% pwm_1.fimo_out[, gene], {
                    if( any( targeted)) {
                      cat( `#query-gene`, ', ', `ortholog-species`, '\n', sep = '')
                      a <- sample( setdiff( org_gene[[ `ortholog-species`]][[ 'V1']], `ortholog-gene`), .N)
                      data.table::set( org_orth, .I, 'ortholog-gene_fake', a)
                      {}
                    }
                  }, by = list( `#query-gene`, `ortholog-species`)]
                  pq_bg <- sapply( org_other, function( org1) {
                    a <- mean( org_gene[[ org1]][[ 1]] %in% pwm_1.fimo_out[, gene])
                    c( a, 1 - a)
                  })
                  score_bg <- sapply( seq( 1e3), function( i) {
                    sum( sapply( colnames( pq_bg), function( org1) {
                      sample( c( 1L, 0L), size = 1L, prob = pq_bg[, org1])
                    }))
                  })
                  local({
                    a <- rev( table( score_bg))
                    .wk[[ 'base_browser']]( '_1_12_01_150848')
                    a <- cumsum( a) / sum( a)
                    r <- rep( 0, length( org_other) + 1)
                    names( r) <- seq( 0, length( org_other))
                    r[ names( a)] <- a
                    r
                    x <- rev( cmm_score[, table( score)])
                    cumsum( x) / sum( x)
                  })
                  1 - pbinom( 0, 2, .3)
                  org_orth[, table( `ortholog-species`)]
                }
                { # @_1/12/01@ ‘靶’和‘非靶’比。行不通
                  cmm_score[, 'targeted' := `#query-gene` %in% pwm_1.fimo_out[, gene]]
                  bg <- cmm_score[ ! ( targeted)]
                  fg <- cmm_score[ ( targeted)]
                  t( t( bg[, prop.table( table( score))]))
                  ## score [,1]
                  ##    1  0.0363458867
                  ##    2  0.0750948072
                  ##    3  0.1407276687
                  ##    4  0.2057973191
                  ##    5  0.2146209590
                  ##    6  0.1713288026
                  ##    7  0.0979611760
                  ##    8  0.0431795141
                  ##    9  0.0120527166
                  ##    10 0.0021777494
                  ##    11 0.0007134007
                  t( t( fg[, prop.table( table( score))]))
                  ## score [,1]
                  ##    1  0.0369558569
                  ##    2  0.0723825059
                  ##    3  0.1384952595
                  ##    4  0.2039963299
                  ##    5  0.2183199103
                  ##    6  0.1744316444
                  ##    7  0.0982770925
                  ##    8  0.0413905597
                  ##    9  0.0128963197
                  ##    10 0.0021918646
                  ##    11 0.0006626567
                }
                gene_not2sample <- intersect( org_gene[[ org_centric]][, V1], pwm_1.fimo_out[, gene])
                r <- .wk[[ 'mclapply']]( seq( 1e3), function( i) {
                  message( i)
                  for( org1 in org_other) {
                    #1
                    #org_gene[[ org1]][, 'V2' := sample( V1)]
                    {
                      #bg <- org_orth[ list( gene2sample, org1), on = c( '#query-gene', 'ortholog-species'), nomatch = {}, `ortholog-gene`]
                      bg <- local({
                        x <- org_orth[ list( org1, gene_not2sample), on = c( 'ortholog-species', '#query-gene'), nomatch = {}, `ortholog-gene`]
                        org_gene[[ org1]][, setdiff( V1, x)]
                      })
                      org_gene[[ org1]][, 'V2' := .wk[[ 'base_sample']]( bg, .N)]
                    }
                    #1
                  }
                  # sapply( org_other, function( x) org_gene[[ x]][, data.table::uniqueN( V2) / .N])
                  org_orth[, {
                    i <- match( `ortholog-gene`, org_gene[[ `ortholog-species`]][[ 'V1']])
                    a <- org_gene[[ `ortholog-species`]][ i, V2]
                    data.table::set( org_orth, .I, 'ortholog-gene-fake', a)
                    {}
                  }, by = `ortholog-species`]
                  if(0){
                    .wk[[ 'pipe1']]( org_orth[, `#query-gene`], unique( x[ tolower( x) %in% pwm_1.fimo_out[, gene]]))
                    .wk[[ 'pipe1']]( org_orth[, `#query-gene`], unique( x[ ! ( tolower( x) %in% pwm_1.fimo_out[, gene])]))
                    
                    gene1 <- cmm_score[ which.max( score), `#query-gene`]
                    cmm_score[ gene1, on = '#query-gene']
                  }
                  data.table::set( org_orth, , 'targeted', org_orth[[ 'ortholog-gene-fake']] %in% pwm_1.fimo_out[[ 'gene']])
                  fake <- org_orth[ c( targeted), {
                    sum( org_other %in% `ortholog-species`)
                  }, by = `#query-gene`]
                  .wk[[ 'dt_setnames']]( fake, 'V1', 'score')
                  #fake[ cmm_score, mean( score >= i.score, na.rm = TRUE), on = '#query-gene']
                  fake[ cmm_score, score >= i.score, on = '#query-gene']
                }, nc = 10, seed = 99)
                data.table::setDT( r)
                p_value <- .wk[[ 'rowMean']]( r)
                q_value <- p.adjust( p_value, 'fdr')
                #q_value <- p.adjust( p_value[ cmm_score[, score > 0]], 'fdr')
                cmm_score[, 'p_value' := p_value]
                cmm_score[, 'q_value' := q_value]
                if(0){
                  cmm_score[ q_value < .05]
                  cmm_score[ q_value > 0, min( q_value)]
                  cmm_score[ p_value > 0, min( p_value)]
                  cmm_score[ p_value == .004, .N]
                  cmm_score[ score == 0, .N]
                }
                .wk[[ 'dt_fwrite']]( cmm_score, fp2)
              }
            }
          }
          { # 输出靶基因 <<_1_10_22_234323>>
            pwm_target <- .wk[[ 'do_list']]( dimnames( target_region_file)[[ 'region']], function( x) {
              File <- .wk[[ 'list_file']]( score_fp2, ms = x)
              names( File) <- .wk[[ 'sub']]( basename( File), paste0( '.', x, '.tsv.gz'), fixed = 1)
              r <- .wk[[ 'do_list']]( File, function( file_1) {
                if( file.size( file_1) == 0) return()
                a <- .wk[[ 'dt_fread']]( file_1)
                a[ q_value < .05, `#query-gene`]
              })
              r <- .wk[[ 'get_fun']]( 'from_list._1_10_22_222000')( r, top_name = 'pwm')
              data.table::setnames( r, 'V1', 'target')
            })
            .wk[[ 'xls_write']]( pwm_target, 'pwm_target.xlsx')
            { # @_1/10/28@ pwm => tf
              motif_TF_fp <- file.path( dirname( .wk[[ 'get_fun']]( 'pwm/_1_07_14_163254')()), 'motif_TF.txt')
              .wk[[ 'sys_head']]( motif_TF_fp)
              motif_TF <- .wk[[ 'dt_fread']]( motif_TF_fp, cn = 0)
              list( motif_TF[ pwm_target[[ 1]][, pwm], on = 'V1', V2, mult = 'all'], )
              .wk[[ 'do_list']]( names( pwm_target), function( Region) {
                for( pwm1 in pwm_target[[ Region]][, unique( pwm)]) {
                  file_in <- file.path( target_region_file.folder( target_region_file[[ org_centric, Region]]), paste0( pwm1, '.fimo_out.tsv.gz'))
                  .wk[[ 'base_browser']]( '_1_11_09_101847')
                  pwm1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
                    sapply(
                      file_in,
                      function( fp1) {
                        .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)}),
                    select = fimo_out_ci_wanted)
                  data.table::setnames( pwm1.fimo_out, c( names( .wk[[ 'dt_fread']]( file_in, nrows = 0, cn = 1))[ fimo_out_ci_wanted]))
                  #1 每个区域取p值最小的一行
                  data.table::setorderv( pwm1.fimo_out)
                  pwm1.fimo_out <- pwm1.fimo_out[ `p-value` < p_value_cutoff, .SD[ 1], by = sequence_name]
                  #
                  pwm1.fimo_out[, 'gene' := tolower( .wk[[ 're']]( sequence_name, '[^\\|]+'))]
                  .wk[[ 'base_browser']]( '_1_10_29_142455')
                  pwm_target[[ Region]][ pwm1, on = 'pwm']
                  pwm1_target <- pwm_target[[ Region]][ pwm1, on = 'pwm', target]
                  pwm1.fimo_out[ list( pwm1_target), on = 'gene']
                  pwm_target[[ Region]][ pwm1, on = 'pwm', p_value := 1]
                }
              })
              tf_target <- .wk[[ 'do_list']]( pwm_target, function( x) {
                r <- list( motif_TF[ x[, pwm], on = 'V1', V2, mult = 'all'], x[, target])
                data.table::setDT( r)
                data.table::setnames( r, c( 'TF', 'target'))
              })
            }
            .wk[[ 'sys_ls']]()
            getwd()
            .wk[[ 'file_rsync']]( '/media/sda1/wk/work/xm/_1/06/24/230251/cmm/pwm_target.xlsx', dry = 0)
            .wk[[ 'file_rsync']]( '/media/sda1/wk/work/xm/_1/06/24/230251/cmm/pwm_target.xlsx', ssh = '')
          }
          { # 统计
            .wk[[ 'sys_ls']]( score_fp2)
            if(0).wk[[ 'do_list']]( dimnames( target_region_file)[[ 'region']], function( x) {
              table( sapply( .wk[[ 'list_file']]( score_fp2, ms = x), function( fp1) {
                file.size( fp1) == 0
              }))
            })
            if(0).wk[[ 'do_list']]( dimnames( target_region_file)[[ 'region']], function( x) {
              a <- sapply( .wk[[ 'list_file']]( score_fp2, ms = x), function( fp1) {
                if( file.size( fp1) > 0) {
                  a <- .wk[[ 'dt_fread']]( fp1)
                  q <- a[, q_value]
                  sum( q < .05)
                } else 0
              })
              summary( a)
            })
            a <- sapply( .wk[[ 'list_file']]( 'score'), function( fp1) {
              if( file.size( fp1) > 0) {
                a <- .wk[[ 'dt_fread']]( fp1)
                b <- a[, V4[ 1], by = V1]
                .wk[[ 'dt_setnames']]( b, c( 'orth_grp', 'p_value'))
                b[, 'q_value' := p.adjust( p_value, 'fdr')]
                c( b[, sum( q_value < .05)], b[ a, sum( q_value < .05), on = list( orth_grp == V1)])
              } else c( 0, 0)
            })
            apply( a, 1, summary)
            ## Min.      0.0000   0.00000
            ## 1st Qu.   2.0000   3.00000
            ## Median    5.0000   7.00000
            ## Mean     17.6973  31.01959
            ## 3rd Qu.  19.0000  34.00000
            ## Max.    214.0000 430.00000
          }
          if(0){ # 错误做法
            cmm_score <- {
              a <- pwm_1.fimo_out[, {
                if( org_centric %in% org) {
                  list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
                }
              }, by = orth_grp]
              a[ score > 0]
            }
            cmm_score[, table( score)]
            #   1    2    3    4    5    6    7    8    9   10   11
            # 383  421  643 1106 1505 1836 1842 1938 2149 2817 6279
            #    1     2
            # 5509 13440
            cmm_score_fake <- .wk[[ 'mclapply']]( seq( 1e3), function( i) {
              message( i)
              org_orth <- org_orth[, {
                list( orth_grp, 'gene' = sample( gene))
              }, by = org]
              data.table::set( pwm_1.fimo_out, , 'orth_grp', org_orth[ match( pwm_1.fimo_out[[ 'gene']], gene), orth_grp])
              a <- pwm_1.fimo_out[, {
                if( org_centric %in% org) {
                  list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
                }
              }, by = orth_grp]
              a[ cmm_score[, gene], score, on = 'gene']
            }, nc = 10)
            table( cmm_score_fake[[ 1]])
            r <- sapply( cmm_score_fake, function( x) {
              cmm_score[, score] > x
            })
            summary( .wk[[ 'rowMean']]( r))
            ##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
            ## 0.1560  0.2120  0.4290  0.3685  0.4440  0.5000
            ##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
            ## 0.1550  0.2130  0.4290  0.3683  0.4440  0.4980
            ## 12个物种
            ##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
            ## 0.0790  0.2970  0.5260  0.4938  0.7240  0.7880
          }
          {
            cmm_score <- pwm_1.fimo_out[, {
              if( org_centric %in% org) {
                list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
              }
            }, by = orth_grp]
            cmm_score_fake <- local({
              base::RNGkind( "L'Ecuyer-CMRG")
              set.seed( 99)
              .wk[[ 'mclapply']]( seq( 1e3), function( i) {
                message( i)
                pwm_1.fimo_out <- pwm_1.fimo_out[, {
                  r <- as.list( .SD)#mget( names( .SD))
                  if( org != org_centric) {
                    i <- sample( seq( .N))
                    r[[ 'gene']] <- r[[ 'gene']][ i]
                    r[[ 'org']] <- r[[ 'org']][ i]
                  }
                  r
                }, by = org]
                .wk[[ 'base_browser']]( '_1_08_10_084142')
                pwm_1.fimo_out[ 'ORTHO05D000115', on = 'orth_grp']
                a <- pwm_1.fimo_out[, {
                  if( org_centric %in% org) {
                    list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
                  }
                }, by = orth_grp]
                a[ cmm_score[, gene], score, on = 'gene']
              }, nc = 1)
            })
            table( cmm_score_fake[[ 1]] == cmm_score[, score])
            r <- sapply( cmm_score_fake, function( x) {
              x >= cmm_score[, score]
            })
            p_value <- .wk[[ 'rowMean']]( r)
            summary( p_value)
            #   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
            # 0.2280  0.3020  0.5030  0.5435  0.7270  1.0000
            sum( p_value == 0)
            sum( p_value < .05)
            sum( p.adjust( p_value, 'fdr') < .05)
            cmm_score[ which( p_value == 0)]
            .wk[[ 'rowSum']]( r[ which( p_value == 0),])
            pwm_1.fimo_out
          }
          
          cmm_score <- local({ # <<_1_08_03_104625>>
            n <- pwm_1.fimo_out[ org %in% org_centric, .wk[[ 'dt_uniqN']]( gene)]
            pwm_1.fimo_out[, .wk[[ 'dt_uniqN']]( gene)]
            v1 <- vector( mode( ''), n)
            v2 <- vector( mode( 0), n)
            r <- .wk[[ 'dt_as']]( list( gene = v1, orth_grp = v1, cmm_score = v2))
            current_row <- 0L
            pwm_1.fimo_out[ org %in% org_centric, {
              current_row <<- current_row + 1L
              message( current_row)
              gene_1 <- gene
              orth_grp_1 <- org_orth[ match( gene_1, gene), orth_grp]
              i <- r[, match( orth_grp_1, orth_grp, nomatch = 0)]
              #if( current_row == 2L) .wk[[ 'base_browser']]( '_1_08_03_093035')
              score_1 <-
                if( i) {
                  r[[ 'cmm_score']][ i]
                } else {
                  orth_grp_1.org_other.gene <- org_orth[ list( orth_grp_1, org_other), unique( gene), on = c( 'orth_grp', 'org'), nomatch = 0]
                  pwm_1.fimo_out[ orth_grp_1.org_other.gene, data.table::uniqueN( org), on = 'gene', nomatch = 0L]
                }
              data.table::set( r, current_row, 'gene', gene_1)
              data.table::set( r, current_row, 'orth_grp', orth_grp_1)
              data.table::set( r, current_row, 'cmm_score', score_1)
              {}
            }, by = gene]
            r
          })
          pwm_1.fimo_out[, match( gene, )]
          a=merge( pwm_1.fimo_out, org_orth, by = 'gene')
          org_orth
          cmm_score <- pwm_1.fimo_out[ org == org_centric, {
            gene_1 <- gene
            orth_grp_1 <- org_orth[ match( gene_1, gene), orth_grp]
            org_orth[ list( orth_grp_1, org_other), .wk[[ 'dt_uniqN']]( org), on = c( 'orth_grp', 'org'), nomatch = 0]
          }, by = gene]
          cmm_score <- org_orth[, {
            if( org_centric %in% org) {
              #.SD; .wk[[ 'base_browser']]( '_1_08_03_084424')
              pwm_1.fimo_out[ gene, {
                org <- unique( org)
                if( org_centric %in% org) {
                  length( org) - 1
                }
              }, on = 'gene', nomatch = 0]
            }
          }, by = orth_grp]
          cmm_score[, table( V1)]

          cmm_score_fake <- xxx
          
          org_orth
          
          .wk[[ 'sys_head']]( x[ 3])
          org_orth[ gene %in% 'VMungo0251G3683']
          # org_orth[, .N, by = gene][, .wk[[ 'dt_uniqN']]( N)] # 1
        }
      }

      # 同源基因
      org_orth <- local({
        gene_folder <- .wk[[ 'get_fun']]( '基因/_1_06_22_155510')() # <<_1_08_07_211952>>
        orth_fp <- file.path( gene_folder, 'genefamily_data.ORTHOFAM.csv.gz')
        orth_fp_con <- pipe( .wk[['sys_cat_skip']]( orth_fp), 'r')
        r <- .wk[[ 'get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( v1 = org_v, fp = orth_fp_con, ci1 = 2)
        .wk[[ 'dt_setnames']]( r, c( 'orth_grp', 'org', 'gene'))
      })
      if(0){
        a <- org_orth[, .wk[[ 'dt_uniqN']]( org), by = orth_grp]
        .wk[[ 'dt_reset_name']]( a)
        a[, .wk[[ 'base_table']]( V2)]
        ##     1     2     3     4     5     6     7     8     9    10    11    12
        ## 55165  1361   491   308   259   155   165   152   204   457  1287  7412
      }

      if(0){ # 要求同源基因家族在大豆有基因
        a <- org_orth[, if( 'gma' %in% org) .SD, by = orth_grp]
        a <- a[, .wk[[ 'dt_uniqN']]( org), by = orth_grp]
        .wk[[ 'dt_reset_name']]( a)
        a[, .wk[[ 'base_table']]( V2)]
        ##    1    2    3    4    5    6    7    8    9   10   11   12
        ## 5264  377  231  180  161   89  114  134  187  446 1284 7412
      }
      target_region_file[ 1]
      { # 每次处理1个pwm @_1_08_02_222524@
        pwm_db <- {
          a <- lapply( target_region_file, function( x) {
            x <- target_region_file.folder( x)
            x <- .wk[[ 'list_file']]( x, F = 0)
            .wk[[ 'sub']]( x, '(?i)\\.fimo_out\\.tsv\\.gz$')
          })
          sort( unique( unlist( a)))
        }
        length( pwm_db)
        fimo_out_ci_wanted <- c( 1, 6)
        p_value_cutoff <- 1e-4
        org_centric <- 'gma'
        org_other <- .wk[[ '%rm%']]( org_v, org_centric)
        .wk[[ 'folder_path']]( 'score')
        pwm_1 <- 'M00216_2.00'
        for( pwm_1_i in seq_along( pwm_db)) {
          pwm_1 <- pwm_db[ pwm_1_i]
          fp2 <- file.path( 'score', paste0( pwm_1, '.tsv.gz'))
          if( file.exists( fp2)) next
          .wk[[ 'hs.msg']]( fp2)
          pwm_1.fimo_out_fp <- {
            x <- sapply( target_region_file, function( x) {
              target_region_file.folder( x)
            })
            x <- file.path( x, paste0( pwm_1, '.fimo_out.tsv.gz'))
            names( x) <- names( target_region_file)
            x[ file.exists( x)]
          }
          if(0){
            .wk[[ 'sys_less']]( 'score/M00153_2.00.tsv.gz')
            .wk[[ 'sys_ls']]( pwm_1.fimo_out_fp[ 1])
            file.size( pwm_1.fimo_out_fp)
            unlink( pwm_1.fimo_out_fp)
            .wk[[ 'grepV']]( pwm_file, 'M00153_2')
          }
          pwm_1.fimo_out <- .wk[[ 'get_fun']]( '从多个文件读._1_08_03_201125')(
            sapply( pwm_1.fimo_out_fp, function( fp1) {
              .wk[[ 'sys_cat_skip']]( fp1, just_skip = 1)
            }),
            select = fimo_out_ci_wanted
          )
          if( ! pwm_1.fimo_out[, .N]) {
            .wk[[ 'sys']]( c( 'touch', .wk[[ 'sys_safe_file_path']]( fp2)))
            next
          }
          data.table::setnames( pwm_1.fimo_out, c( names( .wk[[ 'dt_fread']]( pwm_1.fimo_out_fp[ 1], nrows = 0, cn = 1))[ fimo_out_ci_wanted]))
          pwm_1.fimo_out <- pwm_1.fimo_out[ `p-value` < p_value_cutoff, .SD[ which.min( `p-value`)], by = sequence_name] # 每个区域取p值最小的一行
          pwm_1.fimo_out[, 'gene' := .wk[[ 're']]( sequence_name, '[^\\|]+')]
          data.table::set( org_orth, , 'targeted', ifelse( org_orth[[ 'gene']] %in% pwm_1.fimo_out[[ 'gene']], 1L, NA))
          cmm_score <- org_orth[ ! is.na( targeted), {
            if( org_centric %in% org) {
              list( gene = gene[ org %in% org_centric], score = data.table::uniqueN( org) - 1)
            }
          }, by = orth_grp]
          { # p值，q值
            r <- .wk[[ 'mclapply']]( seq( 1e3), function( i) {
              message( i)
              a <- org_orth[, {
                if( org %in% org_centric) {
                  r <- .SD
                } else {
                  r <- mget( names( .SD))
                  r[[ 'targeted']] <- sample( r[[ 'targeted']])
                  data.table::setDT( r)
                }
                r[ ! is.na( targeted)]
              }, by = org]
              fake <- a[, {
                if( org_centric %in% org) {
                  list( gene = sort( gene[ org %in% org_centric]), score = data.table::uniqueN( org) - 1)
                }
              }, by = orth_grp]
              fake[ cmm_score, score >= i.score, on = 'gene']
            }, nc = 10, seed = 99)
            data.table::setDT( r)
            p_value <- .wk[[ 'rowMean']]( r)
            q_value <- p.adjust( p_value, 'fdr') # <<_1_08_12_175248>> 待办：以家族为单位
            #q_value <- p.adjust( p_value[ cmm_score[, score > 0]], 'fdr')
            cmm_score[, 'p_value' := p_value]
            cmm_score[, 'q_value' := q_value]
            if(0){
              cmm_score[ q_value < .05]
              cmm_score[ q_value > 0, min( q_value)]
              cmm_score[ p_value > 0, min( p_value)]
              cmm_score[ p_value == .004, .N]
              cmm_score[ score == 0, .N]
            }
            .wk[[ 'dt_fwrite']]( cmm_score, fp2)
          }
        }
        { # 统计 <<_1_08_18_083709>>
          table( sapply( .wk[[ 'list_file']]( 'score'), function( fp1) {
            file.size( fp1) == 0
          }))
          a <- sapply( .wk[[ 'list_file']]( 'score'), function( fp1) {
            if( file.size( fp1) > 0) {
              a <- .wk[[ 'dt_fread']]( fp1)
              q <- a[[ 'V5']]
              sum( q < .05)
            } else 0
          })
          summary( a)
          # Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
          # 0.00    3.00    7.00   33.08   34.00  481.00
          table( a)
          a <- sapply( .wk[[ 'list_file']]( 'score'), function( fp1) {
            if( file.size( fp1) > 0) {
              a <- .wk[[ 'dt_fread']]( fp1)
              b <- a[, V4[ 1], by = V1]
              .wk[[ 'dt_setnames']]( b, c( 'orth_grp', 'p_value'))
              b[, 'q_value' := p.adjust( p_value, 'fdr')]
              c( b[, sum( q_value < .05)], b[ a, sum( q_value < .05), on = list( orth_grp == V1)])
            } else c( 0, 0)
          })
          apply( a, 1, summary)
          ## Min.      0.0000   0.00000
          ## 1st Qu.   2.0000   3.00000
          ## Median    5.0000   7.00000
          ## Mean     17.6973  31.01959
          ## 3rd Qu.  19.0000  34.00000
          ## Max.    214.0000 430.00000
        }
        if(0){ # 错误做法
          cmm_score <- {
            a <- pwm_1.fimo_out[, {
              if( org_centric %in% org) {
                list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
              }
            }, by = orth_grp]
            a[ score > 0]
          }
          cmm_score[, table( score)]
          #   1    2    3    4    5    6    7    8    9   10   11
          # 383  421  643 1106 1505 1836 1842 1938 2149 2817 6279
          #    1     2
          # 5509 13440
          cmm_score_fake <- .wk[[ 'mclapply']]( seq( 1e3), function( i) {
            message( i)
            org_orth <- org_orth[, {
              list( orth_grp, 'gene' = sample( gene))
            }, by = org]
            data.table::set( pwm_1.fimo_out, , 'orth_grp', org_orth[ match( pwm_1.fimo_out[[ 'gene']], gene), orth_grp])
            a <- pwm_1.fimo_out[, {
              if( org_centric %in% org) {
                list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
              }
            }, by = orth_grp]
            a[ cmm_score[, gene], score, on = 'gene']
          }, nc = 10)
          table( cmm_score_fake[[ 1]])
          r <- sapply( cmm_score_fake, function( x) {
            cmm_score[, score] > x
          })
          summary( .wk[[ 'rowMean']]( r))
          ##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
          ## 0.1560  0.2120  0.4290  0.3685  0.4440  0.5000
          ##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
          ## 0.1550  0.2130  0.4290  0.3683  0.4440  0.4980
          ## 12个物种
          ##   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
          ## 0.0790  0.2970  0.5260  0.4938  0.7240  0.7880
        }
        {
          cmm_score <- pwm_1.fimo_out[, {
            if( org_centric %in% org) {
              list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
            }
          }, by = orth_grp]
          cmm_score_fake <- local({
            base::RNGkind( "L'Ecuyer-CMRG")
            set.seed( 99)
            .wk[[ 'mclapply']]( seq( 1e3), function( i) {
              message( i)
              pwm_1.fimo_out <- pwm_1.fimo_out[, {
                r <- mget( names( .SD))
                if( org != org_centric) {
                  i <- sample( seq( .N))
                  r[[ 'gene']] <- r[[ 'gene']][ i]
                  r[[ 'org']] <- r[[ 'org']][ i]
                }
                r
              }, by = org]
              .wk[[ 'base_browser']]( '_1_08_10_084142')
              pwm_1.fimo_out[ 'ORTHO05D000115', on = 'orth_grp']
              a <- pwm_1.fimo_out[, {
                if( org_centric %in% org) {
                  list( 'gene' = gene[ org %in% org_centric], 'score' = data.table::uniqueN( org) - 1)
                }
              }, by = orth_grp]
              a[ cmm_score[, gene], score, on = 'gene']
            }, nc = 1)
          })
          table( cmm_score_fake[[ 1]] == cmm_score[, score])
          r <- sapply( cmm_score_fake, function( x) {
            x >= cmm_score[, score]
          })
          p_value <- .wk[[ 'rowMean']]( r)
          summary( p_value)
          #   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
          # 0.2280  0.3020  0.5030  0.5435  0.7270  1.0000
          sum( p_value == 0)
          sum( p_value < .05)
          sum( p.adjust( p_value, 'fdr') < .05)
          cmm_score[ which( p_value == 0)]
          .wk[[ 'rowSum']]( r[ which( p_value == 0),])
          pwm_1.fimo_out
        }
        
        cmm_score <- local({ # <<_1_08_03_104625>>
          n <- pwm_1.fimo_out[ org %in% org_centric, .wk[[ 'dt_uniqN']]( gene)]
          pwm_1.fimo_out[, .wk[[ 'dt_uniqN']]( gene)]
          v1 <- vector( mode( ''), n)
          v2 <- vector( mode( 0), n)
          r <- .wk[[ 'dt_as']]( list( gene = v1, orth_grp = v1, cmm_score = v2))
          current_row <- 0L
          pwm_1.fimo_out[ org %in% org_centric, {
            current_row <<- current_row + 1L
            message( current_row)
            gene_1 <- gene
            orth_grp_1 <- org_orth[ match( gene_1, gene), orth_grp]
            i <- r[, match( orth_grp_1, orth_grp, nomatch = 0)]
            #if( current_row == 2L) .wk[[ 'base_browser']]( '_1_08_03_093035')
            score_1 <-
              if( i) {
                r[[ 'cmm_score']][ i]
              } else {
                orth_grp_1.org_other.gene <- org_orth[ list( orth_grp_1, org_other), unique( gene), on = c( 'orth_grp', 'org'), nomatch = 0]
                pwm_1.fimo_out[ orth_grp_1.org_other.gene, data.table::uniqueN( org), on = 'gene', nomatch = 0L]
              }
            data.table::set( r, current_row, 'gene', gene_1)
            data.table::set( r, current_row, 'orth_grp', orth_grp_1)
            data.table::set( r, current_row, 'cmm_score', score_1)
            {}
          }, by = gene]
          r
        })
        pwm_1.fimo_out[, match( gene, )]
        a=merge( pwm_1.fimo_out, org_orth, by = 'gene')
        org_orth
        cmm_score <- pwm_1.fimo_out[ org == org_centric, {
          gene_1 <- gene
          orth_grp_1 <- org_orth[ match( gene_1, gene), orth_grp]
          org_orth[ list( orth_grp_1, org_other), .wk[[ 'dt_uniqN']]( org), on = c( 'orth_grp', 'org'), nomatch = 0]
        }, by = gene]
        cmm_score <- org_orth[, {
          if( org_centric %in% org) {
            #.SD; .wk[[ 'base_browser']]( '_1_08_03_084424')
            pwm_1.fimo_out[ gene, {
              org <- unique( org)
              if( org_centric %in% org) {
                length( org) - 1
              }
            }, on = 'gene', nomatch = 0]
          }
        }, by = orth_grp]
        cmm_score[, table( V1)]

        cmm_score_fake <- xxx
        
        org_orth
        
        .wk[[ 'sys_head']]( x[ 3])
        org_orth[ gene %in% 'VMungo0251G3683']
        # org_orth[, .N, by = gene][, .wk[[ 'dt_uniqN']]( N)] # 1
      }
      # 获取所有fimo结果文件的行数
      number_of_row <- local({
        a <- sapply( names( target_region_file), function( org1) {
          org1_fp <- target_region_file.folder( target_region_file[ org1])
          fimo_out_fp <- .wk[[ 'list_file']]( org1_fp)
          r <- .wk[[ 'mclapply']](
            fimo_out_fp,
            function( fp) {
              message( fp)
              r <- 0
              if( length( readLines( fp, 1)))
                r <- .wk[[ 'dt_fread']]( fp, select = 'p-value')[ `p-value` <= p_value_cutoff, .N]
              r
            },
            nc = 10
          )
          do.call( base::sum, r)
        })
        sum( a)
      })
      # 预分配空间
      fimo_out <- local({
        a <- vector( 'character', number_of_row)
        r <- .wk[[ 'dt']]( 'org' = a)
        .wk[[ 'dt_set']]( r, , 'pwm', a)
        .wk[[ 'dt_set']]( r, , 'gene', a)
        .wk[[ 'dt_set']]( r, , 'p-value', 1)
        r
      })
      local({
        next_row_i <- 1
        for( org1 in names( target_region_file)) {
          org1.fimo_out.folder <- target_region_file.folder( target_region_file[ org1])
          org1.fimo_out.file <- .wk[[ 'list_file']]( org1.fimo_out.folder)
          for( pwm1i in seq_along( org1.fimo_out.file)) {
            org1.fimo_out.file_1 <- org1.fimo_out.file[ pwm1i]
            if( ! length( readLines( org1.fimo_out.file_1, 1)))
              next
            pwm1 <- .wk[[ 'sub']]( basename( org1.fimo_out.file_1), '\\.fimo_out\\.tsv\\.gz$')
            pwm1.fimo_out <- .wk[[ 'dt_fread']]( org1.fimo_out.file_1, select = c( 'sequence_name', 'p-value'))
            pwm1.fimo_out[ `p-value` <= p_value_cutoff, {
              row2fill <- seq.int( next_row_i, length.out = .N)
              .wk[[ 'dt_set']]( fimo_out, row2fill, 'org', org1)
              .wk[[ 'dt_set']]( fimo_out, row2fill, 'pwm', pwm1)
              .wk[[ 'dt_set']]( fimo_out, row2fill, 'gene', .wk[[ 're']]( sequence_name, '[^\\|]+'))
              .wk[[ 'dt_set']]( fimo_out, row2fill, 'p-value', `p-value`)
              next_row_i <<- next_row_i + .N
            }]
          }
        }
      })
      fimo_out[, summary( `p-value`)]
      #1 cmm
      pwm_v <- fimo_out[, unique( pwm)]
      for( pwm1 in pwm_v) {
        gene <- local({
          a <- fimo_out[ org %in% org_centric, unique( gene)]
          fimo_out[ pwm %in% pwm1]
          fimo_out.subset <- .wk[[ 'dt_subset_sample']]( fimo_out, 'pwm', n = 2)
          cmm_score <- fimo_out.subset[, {
            sapply( gene[ org %in% org_centric], function( gene_1) {
              
            })
          }, by = pwm]
          fimo_out.subset[ TRUE]
          b <- org_orth[, if( ( org_centric %in% org) && ( .wk[[ 'dt_uniqN']]( org) > 1)) gene[ org %in% org_centric], by = orth_grp]
          intersect( a, b[[ 2]])
        })
        org_orth[, {
          a <- unique( org)
          if( ( length( a) > 1) && ( org_centric %in% a)) .SD
        }, by = orth_grp]
        cmm_score <- local({
          r <- vector( mode( 1L), length( gene))
          for( gene_1i in seq_along( gene)) {
            message( gene_1i)
            gene_1 <- gene[ gene_1i]
            orth_grp_1 <- org_orth[, orth_grp[ match( gene_1, gene)]]
            fimo_out
            r[ gene_1i] <-org_orth[ orth_grp %in% orth_grp_1, .wk[[ 'dt_uniqN']]( org)]
          }
          .wk[[ 'add_name']]( gene, r)
        })
        if(0){
          .wk[[ 'base_table']]( cmm_score)
          ##    2     3
          ## 1456 21861
        }
        #2 p值
        fake_n <- 1e1
        gene_1i <- 1
        fake_1i <- 1
        fg <- cmm_score[ gene_1]
        bg <- vector( mode( 0), length( gene))
        names( bg) <- gene
        for( gene_1i in seq_along( gene)) {
          gene_1 <- gene[ gene_1i]
          orth_grp_1 <- org_orth[, orth_grp[ match( gene_1, gene)]]
          orth_grp_1.org_gene_n <- org_orth[ orth_grp %in% orth_grp_1, tapply( gene, org, length)]
          seq.int( org_orth[, .wk[[ 'dt_uniqN']]( orth_grp)])
          
          org_orth[, if( i._1_07_23_103216 %in% xxx) {}, by = orth_grp]
          lapply( setdiff( names( orth_grp_1.org_gene_n), org_centric), function( org1) {
            n1 <- orth_grp_1.org_gene_n[ org1]
            n1.orth_grp <- org_orth[, sample( setdiff( orth_grp, orth_grp_1), n1)]
            n1.gene <- org_orth[ orth_grp %in% n1.orth_grp, sample( gene, 1), by = orth_grp][[ 2]]
            'xxx'
          })
          db <- 'xxx'
          sample( db, xxx)
          r <- 'xxx'
          bg[ gene_1i] <- r
        }
        #2
      }
      #1
      
      .wk[[ 'sys_head']]( x[ 1])
      pwm1.fimo <- .wk[[ 'dt_fread']]( x[ 2], cn = 1, select = c( 'sequence_name', 'p-value'))
      pwm1.fimo[, 'sequence_name' := .wk[[ 're']]( sequence_name, '[^\\|]+')]
      .wk[[ 'dt_setnames']]( pwm1.fimo, 'sequence_name', 'gene')
      pwm1.fimo
      pwm1.fimo[ `p-value` <= p_value_cutoff, .( 'gene' = .wk[[ 're']]( sequence_name, '[^\\|]+'), `p-value`)]
      pwm1.fimo[ `p-value` <= p_value_cutoff, .( 'gene' = .wk[[ 're']]( sequence_name, '[^\\|]+'), `p-value`)]
      pwm1.fimo[, summary( `p-value`)]
    }
  })
}
if(0){
  ## fimo结果。家族信息。

  .wk[['with_wd']](, temp = 1, {
    getwd()
    browser( '_1_07_16_001806')
  })
  #/cygdrive/d/home/.db/xm/_1/07/15/233007
}
