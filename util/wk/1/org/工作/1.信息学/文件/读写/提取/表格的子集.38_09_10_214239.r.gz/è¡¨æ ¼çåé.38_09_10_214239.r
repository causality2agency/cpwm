#
# 4
\( v1 = {}, # 向量
  fp, # 待过滤的表格文件
  ci1,
  inverse = FALSE,
  ci2 = {}, # 若是{}，则输出所有列；若是-1，则不输出ci1
  exclude_ci1 = {}, # 不输出哪些ci1？
  include, exclude, # @_1/08/24@
  head = 0, # fp有表头
  skip = 0, # @_1/08/23/094343@
  once = 0, # 若真，则v1的每个值只匹配到1次就不再尝试匹配
  consecutive = 0, # 仅当v1长度为1起作用。若真，则fp里找到对应值后，若开始不对应，则终止查找。
  ic = 0, # 忽略英文字母大小写
  wj2 = {}, # 放结果的文件。若空，则读到r
  cn = {},
  what = '', # @39/08/04@
  ...
)
{
  fp <- .wk[[ 'file_connection']]( fp)
  on.exit( close( fp), add = TRUE)
  
  if( skip) {
    readLines( fp, skip)
  }
  
  if( head) {
    cn <- names( .wk[[ 'dt_fread']]( text = readLines( fp, 1), cn = 1))
  }

  if( is.list( v1)) {
    if( missing( ci1)) {
      ci1 <- {
        a <- lapply( 1:length( v1), function( i) {
          if( length( v1[[ i]])) {
            name <- names( v1)[ i]
            if( length( name) && nzchar( name)) name else i
          }
        })
        .wk[[ 'nonempty']]( a)
      }
    }
    v1 <- .wk[[ 'nonempty']]( v1)
  } else {
    v1 <- list( v1)
    if( missing( ci1)) {
      ci1 <- list( 1)
    }
  }
  if( missing( ci1)) {
    ci1 <- names( v1)
  }
  if( ! is.list( ci1)) {
    ci1 <- as.list( ci1)
  }
  for( i1 in seq_along( ci1)) {
    if( is.character( ci1[[ i1]])) {
      ci1[[ i1]] <- match( ci1[[ i1]], cn)
    }
  }
  if( length( exclude_ci1)) {
    if( is.character( exclude_ci1)) {
      exclude_ci1 <- match( exclude_ci1, cn)
    } else if( is.numeric( exclude_ci1)) {
      exclude_ci1 <- unlist( ci1[ exclude_ci1])
    }
  }
  
  if( once) {
    browser( '_1_07_17_212916')
  }
  go_on_p <- .wk[[ 'make_function']]( # 是否继续读
    if( once) quote( length( v1)) else quote( TRUE)
  )
  
  if( consecutive) {
    browser( '_1_07_17_212924')
  }
  
  if( missing( wj2)) {
    r <- .wk[[ 'acc_list']]()
  }
  # while( go_on_p())
  repeat {
    x <- readLines( fp, 1e5)
    if( ! length( x)) break
    x <- .wk[[ 'dt_fread']]( text = x, cn = FALSE, sep = '\t', ...)
    if( head) data.table::setnames( x, cn)
    
    # 过滤
    for( i1 in seq_along( v1)) {
      i <- x[[ ci1[[ i1]]]] %in% v1[[ i1]]
      if( .wk[[ 'get_i']]( inverse, i1)) {
        i <- ! i
      }
      if( match( FALSE, i, nomatch = 0)) {
        x <- x[ i]
      }
    }

    if( x[, .N]) {
      if( length( exclude_ci1)) {
        if( ! length( ci2)) {
          ci2 <- 1:ncol( x)
        }
        ci2 <- ci2[ !( ci2 %in% exclude_ci1)]
        exclude_ci1 <- {}
      }
      if( length( ci2)) {
        if( (length( ci2) == 1) && ( ci2 < 0)) {
          ci2 <- .wk[[ '%rm%']]( 1:ncol( x), abs( ci2))
        }
        x <- x[, .SD, .SDcols = c( ci2)]
      }
      if( missing( wj2)) {
        r( 'add', x)
      } else {
        .wk[[ 'dt_fwrite']]( x, file = wj2, append = TRUE)
      }
    }
  }
  if( missing( wj2)) {
    data.table::rbindlist( r( 'get'))
  } else {
    for( a in r( 'get')) {
      .wk[[ 'dt_fwrite']]( a, file = wj2)
    }
    wj2
  }
}
if(0){
  # 在fp的ci1列找v1，然后输出第ci2列 39_03_03_102418
  cmd1 <- if( length( v1)) {
    ## if( ! hs.grepl( readLines( fp, 1), '\\t')) # 若fp只有1列，则下面的/^[^\t]*/会有问题
    ##   hs.browser( '39.05.25.165944', debug = 0)
    paste0( 'while( <>) {
  chomp;
  $v{ ', if( ic) 'lc( $_)' else '$_', '} = 1;
}
open( F1, ', .env_wengkai[['str_quote']]( paste( .env_wengkai[['sys_cat_skip']]( fp, cn = 0), '|')), ');',
if( head) '
$a = <F1>;
print( $a);'
, '
while( <F1>) {',
hs.switch(
  ci1,
  1, '
  /^[^\t]*/;
  $f_ci1 = $&;',
  2, '
  /\t([^\t]*)/;
  $f_ci1 = $1;',
  .sys( '
  chomp;
  @F = split( "\t");
  $f_ci1 = $F[ ', ci1 - 1, '];
')
),
if( ic) '
  $f_ci1 = lc( $f_ci1);',
'
  if( exists( $v{ $f_ci1})) {',
if( ( length( v1) == 1) && consecutive) '
    $found = 1;',
if( length( ci2)) {
  paste0( '
    print( ', paste( paste0( '$F[ ', ci2 - 1, ']'), collapse = ', "\t", '), ', "\n");')
} else
  paste0( 'print( $_', if( ci1 > 2) ', "\n"', ');'),
if( once) '
    delete( $v{ $f_ci1});
    if( %v == 0) {
      close( F1);
      exit;
    }'
, '
  }',
if( ( length( v1) == 1) && consecutive)
  ' else {
    if( $found) {
      close( F1);
      exit();
    }
  }', '
}
close( F1);')
  } else
      paste0( '
open( F1, ', shQuote( paste( .env_wengkai[['sys_cat_skip']]( fp, cn = 0), '|')), ');',
if( length( ci2)) {
  paste0( '
$\" = "\t";
while( <F1>) {
  chomp;
  @F = split( "\t");
  ', paste0( 'print( "@F[(', paste( ci2 - 1, collapse = ', '), ')]\n");'), '
}')
} else
  'while( <F1>) { print;}'
)
  if( what == 'cmd')
    return( cmd1)
  message( cmd1)
  .wk[[ 'with_wd']]( fp, .env_wengkai[['get_fun']]( '1.信息学/文件/读写/向量到perl到结果.38_09_26_203407')( v1, cmd1, wj2 = wj2, cn = cn, ...))
}
if(0){
  fp <- '~/swxx/sj/db/pubchem/ftp.ncbi.nlm.nih.gov/pubchem/Compound/Extras/CID-SMILES.gz'
  .env_wengkai[['sys_head']]( db.fp)
  v1 <- c( 'CCN1C=NC2=C(N=CN=C21)N', 'C1(C(C(C(C(C1O)O)OP(=O)(O)O)O)O)O')

  fp='~/a.txt'
  cat( paste( '#', letters, sep = '\t'), sep = '\n', file = fp)
  .env_wengkai[['sys_head']](fp)
  v1=c('c', 'e', 'g')
  
  a = .env_wengkai[['get_fun']]( '1.信息学/文件/读写/提取/表格的子集.38_09_10_214239')( v1 = v1, fp = fp, ci1 = 2, ci2 = {})
}
